/**

HackerGame default javascript file

**/
HackerGame = {};
(function ($, hg) {
	// ===========================================
	// Internal objects and methods initialization
	// ===========================================
	var i18n, // language object
		login = function(user, password, fn) { // login function
			// TODO: do something
			fn(true);
		},
		initAssignment = function () { // Prepare assignment
			hg.mail.close();
			$("#link-page-game").removeClass("disabled");
			hg.action.page("game");
			hg.action.tab("assignment");
		},
		startAssignment = function () { // Start workign on assignment
			hg.assignment.isRunning = true;
			hg.assignment.nextTask();
			hg.assignment.startTimer();
			hg.action.tab("task");
		},
		initDynamicFields = function (selector) {
			$((selector || "body") + " .dyn").each(function () {
				var field, attr = $(this).attr("data-field");
				if (attr) {
					attr = attr.split(".");
					if (attr.length > 1) {
						field = hg.config;
						$.each(attr, function (_, elt) {
							field = field[elt] || {};
						});
					}
					if (field) {
						$(this).text(field);
					}
				}
			});
		},
		init = function(settings) {
			var $obj = this;

			// Initialize available task list
			$.each(hg.config.assignments, function (i, ass) {
				var $tr = $(document.createElement("tr")).addClass("ass-"+ass.id),
					$tdName = $(document.createElement("td")).addClass("ass-name"),
					$tdCurrent = $(document.createElement("td")).addClass("ass-current-score"),
					$tdBest = $(document.createElement("td")).addClass("ass-best-score"),
					$a = $(document.createElement("a"));
				$a.attr("href", "#/assignment/" + ass.id).text(hg.t(ass.name));
				$tdName.append($a);

				$tdCurrent.text("-");
				$tdBest.text(ass.bestScore || "-");
				
				$tr.append($tdName).append($tdCurrent).append($tdBest);

				$("table.assignment-list").append($tr);
			});

			hg.config = $.extend(hg.config, settings);

			if (hg.config.loginRequired) {
				hg.config.terminal.login = login;
			}
			hg.config.terminal.completion = hg.commandCompletion;
			hg.config.terminal.prompt = function (fn) {
				var comp = hg.state.computer,
					props = comp.properties,
					user = props.user,
					dir = (comp.pwd == "/" && "/") || null,
					hostname = props.hostname;
				if (!dir) {
					dir = comp.pwd;
					if (dir == ("/home/"+user)) {
						dir = "~";
					}
					else {
						dir = dir.split("/");
						dir = dir[dir.length-1];
					}
				}
				fn("[" + user + "@" + hostname + " " + dir + "]$ ");
			};

			$("#anon-sama").popover();

			hg.refreshTranslations();
			hg.state = new hg.cons.State();

			hg.term = $obj.terminal(hg.exec, hg.config.terminal);
			hashChange(null);

			$("body").removeClass("loading");

			return $obj;
		},
		hashChange = function (evt) { // event listener for hash changing
			var hash = window.location.hash,
				segments = hash ? hash.split("/") : [],
				command, args;
			if (evt) { evt.preventDefault(); }
			if (segments.length > 1) {
				command = segments[1];
				if (command && hg.action[command]) {
					args = segments.slice(2);
					args = args || [];
					hg.action[command].apply(this, args);
				}
				window.location.hash = "";
			}
			
		};


	// =========================
	// Containers initialization
	// =========================

	hg.cons = {}; // constructors
	hg.network = {}; // network methods
	hg.util = {}; // utility methods
	hg.action = {}; // action methods
	hg.include = {}; // includer object, called from assignments

	// ==============
	// Public methods
	// ==============

	// Translation methods
	hg.t = function (string) {
		return (i18n && i18n[string]) || string;
	};

	hg.refreshTranslations = function (selector) {
		selector = selector ? (selector + " ") : "";
		$(selector + ".i18n").each(function () {
			var defaultString = $(this).attr("data-lang");
			$(this).text(hg.t(defaultString));
		});
	};

	// Loader (assignments and languages)
	hg.load = {
		assignment: function (tasks, other) {
			var title, body, $instructions, $tasksHtml, $learnMore, $tryItOut;
			initDynamicFields();

			title = $("#stash").find("#ass-title").text();
			body = $("#stash").find("#ass-greeting").html();
			$instructions = $("#stash").find("#ass-instructions").clone();
			$tasksHtml = $("#stash").find("#ass-tasks").clone();
			$learnMore = $("#stash").find("#ass-learn-more").clone();
			$tryItOut = $("#stash").find("#ass-try-it-out").clone();

			hg.assignment.numOfTasks = tasks.length;
			hg.assignment.startTime = other.startTime;
			hg.timer.set(other.startTime);
			$.each(tasks, function (i, task) {
				var html = $tasksHtml.find("." + task.id).html();
				hg.assignment.tasks[i] = new hg.cons.Task(task, html);
			});
			
			hg.assignment.successCallback = other.successCallback || function () {};
			hg.assignment.failCallback = other.failCallback || function () {};

			// Parse HTML
			$("#tab-assignment .instructions").html($instructions);
			$("#tab-task").html($(document.createElement("ol")).addClass("tasks-list"));
			$("#tab-learn-more").html($learnMore);
			$("#tab-try-it-out").html($tryItOut);

			hg.mail.recieve({
				subject: title,
				isSensei: true,
				body: body,
				button: {
					name: "Start",
					action: initAssignment
				}
			});
			$("#stash").empty();
		},
		language: function (langId, langObj) {
			if (typeof(langId) == "object") { langObj = landId; }
			else if (langObj) { hg.lang = langId; }
			i18n = $.extend(i18n, langObj);
		}
	};

	// Indicators
	hg.ind = {
		modal: false
	}

	// Mail system
	hg.mail = {
		message: undefined,
		setNew: function() {
			if (!$("#mail").is(".red-alert")) {
				$("#mail").addClass("red-alert");
			}
			$("#mail").hgBlink();
		},
		setEmpty: function () {
			$("#mail").removeClass("red-alert");
		},
		recieve: function (message, clickOpen) {
			hg.mail.message = {
				sender: message.isSensei ? "sensei" : (message.sender || "anon"),
				isSensei: message.isSensei,
				body: message.body,
				button: message.button || null
			};
			hg.mail.setNew();
		},
		open: function () {
			var img, button, title;
			if (hg.mail.message && ! hg.ind.modal) {
				img = hg.mail.message.isSensei ? "anon-small" : "any";
				img = hg.config.basePath + hg.config.imagesPath + img + ".png";
				title = "Message from <strong>" + hg.mail.message.sender + "</strong>";
				$("#mailIcon").attr("src", img).css({
					display: "block",
					margin: "5px auto 0px auto"
				});
				$("#mailMessage .body").html(hg.mail.message.body);
				$("#mailMessage .modal-title").html(title);
				$("#mailMessage").modal("show");
				if (hg.mail.message.button) {
					$("#mailButton").text(hg.mail.message.button.name)
						.click(hg.mail.message.button.action).show();
				}
				else {
					$("#mailButton").hide();
				}
				hg.ind.modal = true;
			}
			$("#mail").popover("hide");
			hg.mail.setEmpty();
		},
		close: function () {
			$("#mailMessage").modal("hide");
		}
	};
	
	// ==============
	// jQuery plugins
	// ==============
	$.fn.hackerGame = function (settings) {
		var $obj = this;
		if (settings && settings.server) {
			// Define init script wrapper
			hg.initServer = function(fnAfterInit) {
				init.call($obj, settings);
				if ($.isFunction(fnAfterInit)) {
					fnAfterInit.call($obj); 
				}
			};
			// The server script needs to call hg.initServer();
			$.getScript(settings.server);
		}
		else {
			init.call($obj, settings);
		}
	};
	$.fn.hackerGameTimer = function() {
		var $obj = this,
			ms = 1000, // number of ms to trigger
			callbackFn,
			display = function() {
				minutes = Math.floor(hg.timer.counter/60);
				seconds = hg.timer.counter - minutes*60;
				minutes = (minutes < 10 ? "0" : "") + minutes;
				seconds = (seconds < 10 ? "0" : "") + seconds;
				if (hg.timer.counter <= 60 && !$obj.is(".red-alert")) {
					$obj.addClass("red-alert");
				}
				$obj.text(minutes + ":" + seconds);
			},
			step = function () {
				var minutes, seconds;
				hg.timer.counter -= 1;
				display();
				if (isNaN(hg.timer.counter) || hg.timer.counter <= 0) { return; }
				hg.timer.status = setTimeout(step, ms);
			};
		hg.timer = {
			counter: 0,
			status: undefined,
			set: function (setCounter, callback) {
				if ($obj.is(".red-alert")) {
					$obj.removeClass("red-alert");
				}
				this.counter = setCounter;
				callbackFn = callback || function () {};
				display();
			},
			start: function () {
				hg.timer.status = setTimeout(step, ms);
			},
			stop: function () {
				counter = 0;
				if (this.status) { clearTimeout(this.status); }
				callbackFn();
			}
		};
		return this;
	};

	// ==============
	// Event listenrs
	// ==============
	$(window).on('hashchange', hashChange);

	// ===================
	// HTML initialization
	// ===================

	$("body").addClass("loading");
	$("body").append($(document.createElement("div")).addClass("loading-gif").html("&nbsp;"));

	$.each(["tab", "input", "page"], function(i, segment) {
		var offset = 6 + segment.length;
		$("#" + segment + "-links").find("li").each(function () {
			if (! $(this).attr("id")) { return; }
			var isSelected = $(this).is(".active"),
				id = $(this).attr("id").substr(offset);
			if (! isSelected) {
				$("#" + segment + "-" + id).hide();
			}
		});
	});
	$("#mailMessage").modal();
	$("#mailMessage").on("hide.bs.modal", function () {
		hg.ind.modal = false;
	});
	
	$("#mail").popover({
		content: "You have mail! Click to continue",
		trigger: "manual",
		placement: "bottom"
	});
	$("#mail").click(function () {
		hg.mail.open();
	});
	$("#button-start-game").click(function () {
		$(this).hide();
		startAssignment();
	});
	
})(jQuery, HackerGame);




/**

HackerGame

**/
(function ($, hg) {
	var notValidIP = [10,127,254,255,1,2,169,172,192],
		randIntGenerator = function (from, to) {
			if (!from) { from = 0; }
			if (!to) { to = 1; }
			return function () { return Math.round(Math.random()*(to-from)+from); };
		},
		fileTypes = {
			"null": "b", 
			"object": "d",
			"string": "t"
		},
		fileTypesLong = {
			"b": "binary",
			"d": "directory",
			"t": "text"
		};
	hg.util.randIP = function () {
		var generator = randIntGenerator(1,255), first = generator();
		while ($.inArray(first, notValidIP) > -1) { first = generator(); }
		return [first, generator(), generator(), generator()].join(".");
	};
	hg.util.randResponseTime = function(from, to) {
		return randIntGenerator(from, to);
	};
	hg.util.fileType = function (file, longName) {
		var type = (file === null && fileTypes["null"]) || fileTypes[typeof(file)];
		return longName ? fileTypesLong[type] : type;
	};
	hg.util.path = function (rawPathString) {
		var ret = null,
			pathString = (rawPathString && 
						  (rawPathString.charAt(rawPathString.length-1) == "/" ? 
						   rawPathString.substr(0, rawPathString.length-1) : rawPathString)) 
				|| null,
			pwdPath = hg.state.computer.pwd.split("/").slice(1),
			path = (pathString && pathString.split("/")) || [];
		if (hg.state.computer.pwd == "/") { pwdPath = []; }
		if (pathString == "/" || (!pathString && hg.state.computer.pwd == "/")) {
			ret = [];
		}
		else if (path) {
			if (pathString && pathString.charAt(0) == "/") {
				// absolute path
				ret = path.slice(1);
			}
			else if (!pathString) {
				// no rawPathString, just add pwdPath
				ret = pwdPath;
			}
			else {
				// combine current path (pwd) with path string
				ret = pwdPath.concat(path);
			}
		}
		return ret;
	};
	hg.util.checkFilePermission = function (path) {
		return $.inArray(path, [
			"/",
			"/bin",
			"/home"
		]) == -1;
	};
	hg.util.fileExists = function (loc) {
		var ret = false;
		hg.util.pathIterator(loc, function (obj) {
			ret = obj !== undefined;
		});
		return ret;
	};
	hg.util.isDir = function (dir) {
		var ret = false;
		hg.util.pathIterator(dir, function (obj) {
			ret = typeof(obj) == "object";
		});
		return ret;
	};
	hg.util.absPath = function (path) {
		return hg.state.computer.pwd + (hg.state.computer.pwd == "/" ? "" : "/") + path;
	};
	hg.util.cleanPath = function (path) {
		var returnPath = [];
		$.each(path.split("/"), function (i, elt) {
			if (elt == ".") { return; }
			if (elt == "..") { returnPath.pop(); }
			else if(elt || i == 0) { returnPath.push(elt); }
		});

		return returnPath.length == 0 ? "/" : returnPath.join("/");
	};
	hg.util.pathIterator = function (dir, fn) {
		var path = hg.util.path(dir),
			res = null,
			place = [hg.state.computer.fs],
			iterator = function (i) {
				if (i < path.length) {
					if (i == -1 || path[i] == ".") { 
						iterator(i+1); 
					}
					else {
						if (path[i] == "..") {
							place.pop();
							if (place.length == 0) {
								place = [hg.state.computer.fs];
							}
						}
						else { 
							place.push(place[place.length-1][path[i]]);
						}
						iterator(i+1);
					}
				}
				else { fn(place[place.length-1]); }
			};
		if (path.length == 0) { fn(place[place.length-1]); }
		else if (path) { iterator(-1); }
	};

	// ===================
	// jQuery util plugins
	// ===================
	$.fn.hgBlink = function (numOfBlinks, time) {
		if (!numOfBlinks) { numOfBlinks = 3; }
		if (!time) { time = 500; }
		$(this).each(function (i, elt) {
			var blink = function (n) {
				if (n > 0) { 
					$(elt).hide(0, function() {
						$(elt).fadeIn(time, function () { 
							blink.call(elt, n-1);
						});
					});
				}
			};
			blink(numOfBlinks);
		});
		return this;
	};
})(jQuery, HackerGame);
/**

HackerGame

**/
(function ($, hg) {
	var addresses = { 
			"127.0.0.1": function () { return hg.state.computer.name; }
		}, 
		dnsTable = { localhost: "127.0.0.1" }, 
		computers = {
			// Define computers here in format location: { ... properties ... }
			"proxy": {
				hostname: "my-machine",
				localIP: "192.168.1.2",
				user: "me",
				externalIP: null,
				visibleFrom: null,
				domain: null,
				commandBlackList: {},
				fs: {
					"bin": {},
					"home": {}
				},
				files: {
					"/dev/random": (function () { return Math.random() })()
				}
			}
		};
	// initialize IP map and DNS table
	$.each(computers, function (name, props) {
		var randomIP;
		if (! props.visibleFrom) {
			do {
				randomIP = hg.util.randIP();
			} while (addresses[randomIP]);
			addresses[randomIP] = name;
			computers[name].externalIP = randomIP;
			if (props.domain) {
				dnsTable[prop.domain] = randomIP;
			}
		}
		else {
			addresses[visibleFrom + ">" + props.localIP] = name;
		}
	});
	hg.cons.Computer = function Computer (name) {
		var props = {};
		if (! name) { name = "localhost"; }
		if (! computers[name]) { return null; }
		this.name = name;
		this.location = typeof addresses[name] == "function" ? 
			addresses[name]() : addresses[name];
		this.pwd = "/";
		this.fs = computers[name].fs;
		$.each(computers[name], function (property, value) {
			if ($.inArray(property, ["fs"]) == -1) { 
				props[property] = value; 
			}
		});
		this.properties = props;

		hg.initComputerCommands(this);
	};
	hg.network.ping = function (location) {
		var isInWeb = addresses[location] || addresses[dnsTable[location]],
			localLocation = hg.state.computer.location + ">" + location,
			isLocal = addresses[localLocation];
		return isInWeb || isLocal;
	};

})(jQuery, HackerGame); 


/**

HackerGame

**/
(function ($, hg) {
	var toText = function (input) {
			var output = "";
			if (typeof(input) === "object") {
				$.each(input, function (_, x) {
					output += x + "\n";
				});
			}
			else { output = input; }
			return output;
		},
		commands = {
			// NETWORK
			"ping": {
				exec: function (loc, num, ttl) {
					var term = this, step, dataString, status, time, 
						responseTime, responseTimeLong, responseTimeShort,
						i = 0,
						timeInSeconds = 1,
						isAvailable = hg.network.ping(loc),
						numOfSuccess = 0,
						timeSuma = 0; 
					if (! num) { num = 5; }
					if (! ttl) { ttl = 60; }
					responseTimeLong = hg.util.randResponseTime(3, ttl*1000);
					responseTimeShort = hg.util.randResponseTime(3, ttl*10);
					responseTime = function () { 
						return Math.random() > 0.2 ? 
							responseTimeShort() : responseTimeLong();
					};
					time = responseTime();
					term.pause();
					step = function () {
						timeSuma += time;
						var proc, stats, continueStep;
						status = isAvailable && Math.random() > 0.05;
						if (status) { numOfSuccess += 1; }
						
						continueStep = function () {
							dataString = "icmp_seq=" + (i + 1) 
								+ " ttl="+ttl+" time=" 
								+ (status ? (time/1000) : ttl) + " ms";
							term.echo("Pinging " + loc + " ... " + dataString + " " + (status ? "OK" : "LOST"));
							i += 1;
							if (i < num) {
								time = responseTime();
								setTimeout(step, timeInSeconds*1000 + time/1000); 
							}
							else {
								proc = ((num-numOfSuccess)/num*100);
								proc = Math.round(proc * 1000)/1000;
								stats = num + " packets transmited, " + numOfSuccess 
									+ " recieved, " 
									+ proc + "% pacet loss, time " + timeSuma;
								term.echo("\n--- " + loc + " ping statistics ---");
								term.echo(stats);
								term.resume();
							}
						};
						if (!status) {
							time += ttl*1000 - time/1000;
							setTimeout(continueStep, ttl*1000 - time/1000);
						}
						else {
							continueStep();
						}
					};
					setTimeout(step, time/1000);
				},
				help: ["ping - send a ping package to remote computer", 
					   "Usage: ping IP|DOMAIN [NUMBER_OF_PINGS=5 [TIME_TO_LIVE=60]]",
					   "TIME_TO_LIVE is in seconds.",
					   "Linux: ping"]
			},
			// FILE SYSTEM
			"cat": {
				exec: function (file) {
					var term = this;
					hg.util.pathIterator(file, function (contents) {
						if (contents === null) {
							term.error("Cannot display binary files.");
						}
						else if (typeof(contents) == "object") {
							term.error("Cannot display directory contents.");
						}
						else {
							term.echo(contents);
						}
					});
				},
				help: ["cat - display file contents",
					   "Usage: cat FILE",
					   "Linux: cat FILE"]
			},
			"tree": {
				exec: function (dir) {
					var path = hg.util.path(dir),
						term = this,
						start = "/",
						place = hg.state.computer.fs,
						node = function (level) {
							var out = "";
							while (level-- > 0) {
								out += "   ";
							} 
							return out + "`--";
						},
						iterator = function (currPlace, level) {
							$.each(currPlace, function (name, file) {
								type = hg.util.fileType(file);
								term.echo(node(level) + name + " [" + type + "]");
								if (type == "d") {
									iterator(file, level+1);
								}
							});
						};

					if (path.length > 0) {
						$.each(path, function (i, sub) {
							start = sub;
							place = place[sub] || {};
						});
						if (! place) {
							term.error("Directory doesn't exist!");
							return;
						}
					}
					term.echo(start);
					iterator(place, 0);
					
				},
				help: ["tree - see the file hierarchy in the form of a tree",
					   "If no directory is specified, the working directory hierarchy",
					   "is displayed.",
					   "Usage: tree [DIRECTORY]",
					   "Linux: tree [DIRECTORY]"]
			},
			"ls": {
				exec: function (folder) {
					var dirs = ". ..";
					hg.util.pathIterator(folder, function (contents) {
						if ($.isPlainObject(contents)) {
							$.each(contents, function (k, _) {
								dirs += " " + k;
							});
						}
					});
					this.echo(dirs);
				},
				help: ["ls - list directory",
					   "Usage: ls [directory]",
					   "Linux: ls [directory]"]
			},
			"mkdir": {
				exec: function (folder) {
					var er = false;
					hg.util.pathIterator(null, function (cont) {
						if (cont[folder]) {
							er = "Directory already exists!";
						}
						else if (/[\/\\ ]+/.test(folder)) { er = "Not a valid name"; }
						else if (/^\./.test(folder)) { er = "First char cannot be dor (.)"; }
						else {
							cont[folder] = {};
						}
					});
					if (er) { this.error(er); } 
				},
				help: ["mkdir - create a directory in the current directory",
					   "Usage: mkdir directory",
					   "Linux: mkdir dir1, [dir2, [dir3, ...]]"]
			},
			"pwd": {
				exec: function () { this.echo(hg.state.computer.pwd); },
				help: ["pwd - path to current directory",
					   "Usage: pwd",
					   "Linux: pwd"]
			},
			"cd": {
				exec: function (fold) {
					var foldName = fold;
					if (fold.charAt(0) != "/") {
						fold = hg.util.absPath(fold);
					}
					if (hg.util.isDir(fold)) {
						hg.state.computer.pwd = hg.util.cleanPath(fold);
						if (hg.state.computer.pwd.length == 0) {
							hg.state.computer.pwd = "/";
						}
					}
					else { this.echo(foldName + " is not a directory"); }
				},
				help: ["cd - change directory",
					   "Usage: cd path",
					   "Linux: cd path"]
			},
			"rm": {
				exec: function (path) {
					var fullPath = null, 
						last=null, 
						term=this, 
						place=hg.state.computer.fs;
					path = hg.util.path(path);
					if (! path) {
						term.error("File or directory doesn't exist!");
					}
					else if (path.length == 0) {
						term.error("Cannot remove root directory.");
					}
					else {
						fullPath = hg.util.cleanPath("/" + path.join("/"));
						if (!hg.util.checkFilePermission(fullPath)) {
							term.error("You do not have permission");
						}
						else {
							path = hg.util.path(fullPath);
							last = path[path.length -1];
							if (path.length == 1) {
								delete place[last];
							}
							else {
								$.each(path, function (i, obj) {
									place = place[obj];
									if (i == path.length - 2) {
										if (typeof(place) == "object" && place[last] !== undefined) { 
											delete place[last]; 
										}
										else {
											term.error("File or directory doesn't exist.");
										}
									}
								});
							}
							if (!hg.util.fileExists(hg.state.computer.pwd)) {
								hg.state.computer.pwd = "/";
							}
						}
					}
				},
				help: ["rm - remove file or directory",
					   "Usage: rm path",
					   "Linux: rm path_to_file OR rmdir path_to_empty_directory"]
			},
			// INTERNAL
			"eval": {
				help: ["eval - execute a JavaScript command", 
					   "Usage: eval COMMAND"]
			},
			"export": {
				help: ["export - store a variable",
					   "Usage: export VARIABLE=VALUE",
					   "Linux: export VARIABLE=VALUE"]
			},
			"sensei": {
				exec: function (input) { this.echo("Message to sensei sent."); },
				fullArgs: true,
				help: ["sensei - send a message to sensei via secure connection",
					   "Usage: sensei MESSAGE"]
			},
			"echo": {
				exec: function (input) { this.echo(input); },
				fullArgs: true,
				help: ["echo - print text in terminal", 
					   "Usage: echo TEXT",
					   "Linux: echo TEXT"]
			},
			"help": {
				exec: function(command) {
					var term = this,
						blackList = hg.state.computer.properties.commandBlackList;
					if (!command) {
						this.echo("Available commands: ");
						$.each(commands, function (cmnd, props) {
							if ($.inArray(cmnd, blackList) > -1) {
								return;
							}
							term.echo(props.help[0]);
						});
						this.echo("\nFor more information type: help COMMAND");
					}
					else if (commands[command]){
						this.echo(toText(commands[command].help));
					}
					else {
						this.error("No information on command " + command);
					}
				},
				help: ["help - display help information", 
					   "Usage: help COMMAND",
					   "Linux: man or COMMAND -h or COMMAND --help"]
			}
		};
	hg.commandCompletion = function (term, string, fn) {
		var candidates = [];
		$.each(commands, function (cmnd, _) {
			if (cmnd.substr(0, string.length) == string) {
				candidates.push(cmnd);
			}
		});
		fn(candidates);
	};
	hg.initComputerCommands = function (computer) {
		$.each(commands, function (name, _) {
			computer.fs.bin[name] = null;
		});
	};
	hg.exec = function(input, term) {
		var segments = input.split(" "),
			fn = segments[0],
			result,
			noError = true,
			attributes = segments.length > 1 ? segments.slice(1) : null;
		if ($.inArray(fn, hg.state.computer.properties.commandBlackList) > -1) {
			noError = false;
			term.error("Command is not defined!");
		}
		else if (commands[fn] && commands[fn].exec) {
			if (commands[fn].fullArgs) { commands[fn].exec.call(term, attributes.join(" ")); }
			else { commands[fn].exec.apply(term, attributes); }
		}
		else if(fn === "eval" || fn === "export") {
			if (attributes) {
				try {
					result = window.eval(attributes.join(" "));
					if (result !== undefined) {
						term.echo(new String(result));
					}
				} catch(e) {
					term.error(new String(e));
            	}
			}
		}
		else {
			noError = false;
			term.error("Command is not defined!");
		}
		if (hg.assignment.evaluate) {
			// Callback is the main task checker.
			// If the input passes the callback
			// You can move to the next task
			var callbackResult = hg.assignment.evaluate.call(term, input, noError),
				status;
			if (callbackResult) {
				hg.assignment.nextTask();
			}
		}
		
	};
})(jQuery, HackerGame);

/**

HackerGame

**/
(function ($, hg) {
	var temp, 
		initTaskHTML = function ($task) {
			var $help, $hint, 
				$btn = $(document.createElement("button")).addClass("btn").addClass("btn-info").addClass("btn-sm");
			$("#tab-task .tasks-list").append($task.append($(document.createElement("br"))));

			$help = $task.find(".help").clone();
			$hint = $task.find(".hint").clone();
			
			if ($help.length > 0) {
				$task.find(".help").replaceWith($btn.addClass("help").text("Help").clone().popover({
					content: $help.html(),
					title: hg.t("Help"),
					placement: "top",
					html: true
				}));
			}
			if ($hint.length > 0) {
				$task.find(".hint").replaceWith($btn.addClass("hint").text("Hint").clone().popover({
					content: $help.html(),
					title: hg.t("Hint"),
					placement: "bottom",
					html: true
				}).on('shown.bs.popover', function () {
					hg.assignment.queue.push("hint");
				}));
			}
			$task.hide().fadeIn("slow", function () {
				$("#tab-task").scrollTop($("#tab-task").get(0).scrollHeight);
			});
		},
		evalAssignmentQueue = function () {
			var task = this,
				actions = {
				hint: function () {
					hg.stats.increment("currentScore", - parseInt(0.75 * task.points, 10));
				}
			};
			if (hg.assignment.queue.length > 0) {
				$.each(hg.assignment.queue, function (i, elt) {
					if (actions[elt]) { actions[elt](); }
				});
				hg.assignment.queue = [];
			}
		},
		closeTask = function (id) {
			$("#tab-task .tasks-list #task-"+id).addClass("completed-task");
			$("#tab-task .tasks-list #task-"+id).find(".hint, .help").popover('destroy').empty().remove();
		},
		loadAssignment = function (assId, callback) {
			var htmlUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".html",
				htmlLangUrl = hg.config.basePath + hg.config.assignmentsPath + assId + "-" + hg.lang + ".html",
				loadJS = function (html) {
					$("#stash").html(html);
					$.getScript(jsUrl, callback);
				},
				jsUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".js";
			$.ajax({
				url: htmlLangUrl,
				method: 'get',
				dataType: 'html',
				success: loadJS,
				error: function() {
					// If no language markup file exists, load the default (english) file
					$.ajax({
						url: htmlUrl,
						method: 'get',
						dataType: 'html',
						success: loadJS
					});
				}
			});
		};
	hg.cons.State = function State(computer, config) {
		this.computer = computer || new hg.cons.Computer(hg.config.defaultComputer);
		
		this.innerState = undefined;
		if (config && typeof config === "object") { //TODO: use extend
			$.each(config, function (property, value) {
				this[property] = value;
			});
		}
	};
	hg.cons.Task = function Task(taskObj, taskHtml) {
		this.id = taskObj.id || null;
		this.evaluate = taskObj.evaluate || function () { return true; };
		this.set = taskObj.set || function () {};
		this.unset = taskObj.unset || function () {};
		this.points = taskObj.points;
		this.html = taskHtml || "";
	};
	hg.cons.Task.prototype.switchTask = function (previousTask) {
		var $li = $(document.createElement("li")).attr("id", "task-" + this.id);
		if (previousTask) { 
			previousTask.unset(); 
		}
		this.set();
		$li.html(this.html);
		initTaskHTML($li);
		hg.assignment.evaluate = this.evaluate;
	};
	hg.cons.Assignment = function Assignment(assignment, loadCallback) {
		this.id = assignment;
		this.currentTask = -1;
		this.numOfTasks = 0; // set with array length
		this.tasks = []; // array of task objects 
		this.isRunning = false;
		this.startTime = 0;
		this.evaluate = function () { return true; };
		this.queue = [];
		loadAssignment(assignment, loadCallback);
	};
	hg.cons.Assignment.prototype.startTimer = function () {
		hg.timer.start();
	};
	hg.cons.Assignment.prototype.nextTask = function () {
		var nextTask,
			prevTask = this.currentTask >= 0 ? this.tasks[this.currentTask] : undefined;
		
		nextTask = this.tasks[this.currentTask + 1];
		this.currentTask += 1;

		

		if (nextTask) { 
			nextTask.switchTask(prevTask);
		}

		if (prevTask) { 
			closeTask(prevTask.id);
			hg.stats.increment({
				currentScore: prevTask.points,
				completedTasks: 1
			});
			evalAssignmentQueue.call(prevTask); 
		}
		
		if (! nextTask) { hg.assignment.complete(); }
	};
	hg.cons.Assignment.prototype.fail = function () {
		hg.timer.stop();
		hg.assignment.failCallback();
	};
	hg.cons.Assignment.prototype.complete = function () {
		var $tr = $(".assignment-list .ass-"+hg.assignment.id),
			bestScore = $tr.find(".ass-best-score").text();
		hg.timer.stop();
		hg.stats.increment({
			completedAssignments: 1,
			overallScore: hg.stats.currentScore
		});
		hg.stats.refresh();
		$tr.find(".ass-name a").addClass("completed-assignment").attr("href", "#");
		
		if (bestScore == "-" || (parseInt(bestScore, 10) < hg.stats.currentScore)) {
			bestScore = hg.stats.currentScore;
		}
		$tr.find("td.ass-best-score").text(bestScore);
		$tr.find("td.ass-current-score").text(hg.stats.currentScore);
		hg.assignment.successCallback();
	};
	hg.stats = {
		refresh: function() {
			var overallAssignments = hg.config.assignments.length,
				tasksInAssignment = hg.assignment.tasks.length;

			$("#stats-completed-tasks").text(hg.stats.completedTasks + "/" + tasksInAssignment);
			$("#stats-completed-assignments").text(hg.stats.completedAssignments + "/" + overallAssignments);
			$("#stats-current-score").text(hg.stats.currentScore);
			$("#stats-best-score").text(hg.stats.bestScore);
			$("#stats-overall-score").text(hg.stats.overallScore);
		},
		increment: function(stat, val, hold) {
			if (typeof(stat) == "object") {
				$.each(stat, function (key, inc) {
					if (hg.stats[key] !== undefined && !$.isFunction(hg.stats[key])) {
						hg.stats[key] += inc;
					}
				});
			}
			else if (hg.stats[stat] !== undefined && !$.isFunction(hg.stats[stat])) { 
				hg.stats[stat] += val; 
			}
			if (! hold) { hg.stats.refresh(); }
		},
		completedAssignments: 0,
		completedTasks: 0,
		bestScore: 0,
		currentScore: 0,
		overallScore: 0
	};

	// Actions (which user can do)
	hg.action.page = function (pageId) {
		var prevPageId = $("#page-links .active").attr("id").substr(10),
			pageDisabled = $("#link-page-" + pageId).is(".disabled"),
			showPage = function () {
				$("#link-page-" + pageId).addClass("active"); 
				$("#page-" + pageId).show("slow");
			};
		if (pageDisabled) { return; }
		if (prevPageId) { 
			$("#link-page-" + prevPageId).removeClass("active"); 
			$("#page-" + prevPageId).hide("slow", showPage);
		}
		else {
			showPage();
		}
	};
	hg.action.input = function (inputId) {
		var prevInputId = $("#input-links .active").attr("id").substring(11),
			showInput = function () {
				$("#link-input-" + inputId).addClass("active"); 
				$("#input-" + inputId).show(0);
			};
		if (prevInputId) {
			$("#link-input-" + prevInputId).removeClass("active"); 
			$("#input-" + prevInputId).hide(0, showInput);
		}
		else {
			showInput();
		}
	};
	hg.action.tab = function (tabId) {
		var prevTabId = $("#tab-links .active").attr("id").substring(9),
			showTab = function () {
				$("#link-tab-" + tabId).addClass("active"); 
				$("#tab-" + tabId).show(0);
			};
		if (prevTabId) {
			$("#link-tab-" + prevTabId).removeClass("active"); 
			$("#tab-" + prevTabId).hide(0, showTab);
		}
		else {
			showTab();
		}
	};
	hg.action.assignment = function (assId) {
		var status = false;
		$.each(hg.config.assignments, function (i, obj) {
			if (obj.id == assId) { status = true; }
		});

		if (! status) { return; }

		hg.assignment = new hg.cons.Assignment(assId, function () {
			hg.refreshTranslations(hg.config.assignmentScopeSelector);
		});

		$("#link-tab-game").removeClass("disabled");
	};
	hg.action.mail = function (cmnd) {
		if (cmnd == "open") { hg.mail.open(); }
	};
})(jQuery, HackerGame);

(function ($, hg) {
	hg.config = {
		assignmentScopeSelector: ".assignment-scope",
		defaultComputer: "proxy",
		loginRequired: true,
		terminal: {
			greetings: 'Welcome!',
			name: 'hacker-terminal',
			height: 400,
			tabcompletion: true,
			prompt: '$ '
		},
		basePath: "",
		assignmentsPath: "ass/",
		imagesPath: "img/",
		assignments: [
			{ 
				id: "intro",
				name: "Introduction to the terminal"
			}
		],
		user: {
			email: "",
			name: "Anon"
		},
		state: {
			completedAssignments: {
				"example": {
					best: 100
				}
			}
		}
	};
})(jQuery, HackerGame);
