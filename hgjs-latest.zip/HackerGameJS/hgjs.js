/**

HackerGame default javascript file

**/
HackerGame = {};
(function ($, hg) {
	var i18n, // language object
		login = function(user, password, fn) {
			// TODO: do something
			fn(true);
		},
		startAssignment = function () {
			hg.mail.close();
			$("#link-page-game").removeClass("disabled");
			hg.action.page("game");
			hg.action.tab("assignment");
		},
		startGame = function () {
			hg.assignment.isRunning = true;
			hg.assignment.nextTask();
			hg.stats.refresh();
			hg.assignment.startTimer();
			hg.action.tab("task");
		},
		init = function(settings) {
			var jObj = this;


			// Initialize available task list
			$.each(hg.config.assignments, function (i, ass) {
				var li = $(document.createElement("li")),
				a = $(document.createElement("a"));
				$(a).attr("href", "#/assignment/" + ass.id).text(hg.t(ass.name));
				li.append(a);
				$("ul.assignment-list").append(li);
			});

			if (settings) { //TODO: use extend
				$.each(settings, function (property, value) {
					hg.config[property] = value;
				});
			}
			if (hg.config.loginRequired) {
				hg.config.terminal.login = login;
			}
			hg.config.terminal.completion = hg.commandCompletion;
			hg.config.terminal.prompt = function (fn) {
				var comp = hg.state.computer,
					props = comp.properties,
					user = props.user,
					dir = comp.pwd,
					hostname = props.hostname;
				fn("[" + user + "@" + hostname + " " + dir + "]$ ");
			};

			$("#anon-sama").popover();

			hg.refreshTranslations();
			hg.state = new hg.cons.State();


			hg.term = jObj.terminal(hg.exec, hg.config.terminal);
			hashChange(null);

			return jObj;
		},
		hashChange = function (evt) {
			var hash = window.location.hash,
				segments = hash ? hash.split("/") : [],
				command, args;
			if (segments.length > 1) {
				command = segments[1];
				if (command && hg.action[command]) {
					args = segments.slice(2);
					args = args || [];
					hg.action[command].apply(this, args);
				}
			}
			if (evt) { evt.preventDefault(); }
		};

	// Public methods
	hg.t = function (string) {
		return (i18n && i18n[string]) || string;
	};
	hg.refreshTranslations = function (selector) {
		selector = selector ? (selector + " ") : "";
		$(selector + ".i18n").each(function () {
			var defaultString = $(this).attr("data-lang");
			$(this).text(hg.t(defaultString));
		});
	};

	// Init internal objects
	hg.cons = {}; // constructors
	hg.network = {}; // network methods
	hg.util = {}; // utility methods
	hg.action = {}; // action methods

	// Loader object
	hg.load = {
		assignment: function (assignment) {
			var status = false;
			$.each(hg.config.assignments, function (i, obj) {
				if (obj.id == assignment) { status = true; }
			});
			if (!status) { return false; }
			hg.assignment = new hg.cons.Assignment(assignment, function () {
				hg.refreshTranslations(hg.config.assignmentScopeSelector);
			});
			return true;
		},
		language: function (langId, langObj) {
			i18n = langObj;
			hg.lang = langId;
		}
	};
	
	// Includer object
	hg.include = {
		computer: function () {},
		command: function() {}
	};

	// jQuery plugin
	$.fn.hackerGame = function (settings) {
		init.call(this);
	};
	$.fn.hackerGameTimer = function() {
		var jObj = this,
			ms = 1000, // number of ms to trigger
			callbackFn,
			display = function() {
				minutes = Math.floor(hg.timer.counter/60);
				seconds = hg.timer.counter - minutes*60;
				minutes = (minutes < 10 ? "0" : "") + minutes;
				seconds = (seconds < 10 ? "0" : "") + seconds;
				if (hg.timer.counter <= 60 && !$(jObj).is(".red-alert")) {
					$(jObj).addClass("red-alert");
				}
				$(jObj).text(minutes + ":" + seconds);
			},
			step = function () {
				var minutes, seconds;
				hg.timer.counter -= 1;
				display();
				if (isNaN(hg.timer.counter) || hg.timer.counter <= 0) { return; }
				hg.timer.status = setTimeout(step, ms);
			};
		hg.timer = {
			counter: 0,
			obj: jObj,
			status: undefined, 
			start: function (setCounter, callback) {
				if ($(jObj).is(".red-alert")) {
					$(jObj).removeClass("red-alert");
				}
				this.counter = setCounter;
				callbackFn = callback || function() {};
				display();
				hg.timer.status = setTimeout(step, ms);
			},
			stop: function () {
				counter = 0;
				if (this.status) { clearTimeout(this.status); }
				callbackFn();
			}
		};
		return this;
	};

	hg.mail = {
		message: undefined,
		setNew: function() {
			if (!$("#mail").is(".red-alert")) {
				$("#mail").addClass("red-alert");
			}
		},
		setEmpty: function () {
			$("#mail").removeClass("red-alert");
			hg.mail.message = undefined;
		},
		recieve: function (message) {
			hg.mail.message = {
				sender: message.isSensei ? "sensei" : (message.sender || "anon"),
				isSensei: message.isSensei,
				body: message.body,
				button: message.button || null
			};
			hg.mail.setNew();
		},
		open: function () {
			var img, button, title;
			if (hg.mail.message) {
				img = hg.mail.message.isSensei ? "anon" : "any";
				img = hg.config.basePath + hg.config.imagesPath + img + ".png";
				title = "Message from <strong>" + hg.mail.message.sender + "</strong>";
				$("#mailIcon").attr("src", img).css({
					display: "block",
					margin: "5px auto 0px auto"
				});
				$("#mailMessage .body").html(hg.mail.message.body);
				$("#mailMessage .modal-title").html(title);
				$("#mailMessage").modal("show");
				if (hg.mail.message.button) {
					$("#mailButton").text(hg.mail.message.button.name)
						.click(hg.mail.message.button.action).show();
				}
				else {
					$("#mailButton").hide();
				}
			}
			$("#mail").popover("hide");
			hg.mail.setEmpty();
		},
		close: function () {
			$("#mailMessage").modal("hide");
		}
	};

	hg.prepareGame = function (tasks, other) {
		var title = $("#stash").find("#ass-title").text(),
			body = $("#stash").find("#ass-greeting").text(),
			instructions = $("#stash").find("#ass-instructions").clone(),
			tasksHtml = $("#stash").find("#ass-tasks").clone(),
			learnMore = $("#stash").find("#ass-learn-more").clone(),
			tryItOut = $("#stash").find("#ass-try-it-out").clone();

		hg.assignment.numOfTasks = tasks.length;
		hg.assignment.startTime = other.startTime;
		$.each(tasks, function (i, task) {
			var html = $(tasksHtml).find("." + task.id).html();
			hg.assignment.tasks[i] = new hg.cons.Task(task, html);
		});
		
		// Parse HTML
		$("#tab-assignment .instructions").html(instructions);
		$("#tab-task").html($(document.createElement("ul")).addClass("tasks-list"));
		$("#tab-learn-more").html(learnMore);
		$("#tab-try-it-out").html(tryItOut);

		hg.mail.recieve({
			subject: title,
			isSensei: true,
			body: body,
			button: {
				name: "Start",
				action: startAssignment
			}
		});
		$("#stash").empty();
	};
	
	$(window).on('hashchange', hashChange);

	// Initialize HTML actions
	$.each(["tab", "input", "page"], function(i, segment) {
		var offset = 6 + segment.length;
		$("#" + segment + "-links").find("li").each(function () {
			if (! $(this).attr("id")) { return; }
			var isSelected = $(this).is(".active"),
				id = $(this).attr("id").substr(offset);
			if (! isSelected) {
				$("#" + segment + "-" + id).hide();
			}
		});
	});
	$("#mailMessage").modal();
	$("#mail").popover({
		content: "You have mail! Click to continue",
		trigger: "manual",
		placement: "bottom"
	});
	$("#button-start-game").click(function () {
		$(this).hide();
		startGame();
	});
	
})(jQuery, HackerGame);
/**

HackerGame

**/
(function ($, hg) {
	var notValidIP = [10,127,254,255,1,2,169,172,192],
		randIntGenerator = function (from, to) {
			if (!from) { from = 0; }
			if (!to) { to = 1; }
			return function () { return Math.round(Math.random()*(to-from)+from); };
		};
	hg.util.randIP = function () {
		var generator = randIntGenerator(1,255), first = generator();
		while ($.inArray(first, notValidIP) > -1) { first = generator(); }
		return [first, generator(), generator(), generator()].join(".");
	};
	hg.util.randResponseTime = function(from, to) {
		return randIntGenerator(from, to);
	};
})(jQuery, HackerGame);
/**

HackerGame

**/
(function ($, hg) {
	var addresses = { 
			"127.0.0.1": function () { return hg.state.computer.name; }
		}, 
		dnsTable = { localhost: "127.0.0.1" }, 
		computers = {
			// Define computers here in format location: { ... properties ... }
			"proxy": {
				hostname: "my-machine",
				localIP: "192.168.1.2",
				user: "me",
				externalIP: null,
				visibleFrom: null,
				domain: null,
				commandBlackList: {},
				filesystem: {
					"/": ["bin", "usr", "home"],
					"/dev/": ["random"],
					"/home/" : ["user"]
				},
				files: {
					"/dev/random": (function () { return Math.random() })()
				}
			}
		};
	// initialize IP map and DNS table
	$.each(computers, function (name, props) {
		var randomIP;
		if (! props.visibleFrom) {
			do {
				randomIP = hg.util.randIP();
			} while (addresses[randomIP]);
			addresses[randomIP] = name;
			computers[name].externalIP = randomIP;
			if (props.domain) {
				dnsTable[prop.domain] = randomIP;
			}
		}
		else {
			addresses[visibleFrom + ">" + props.localIP] = name;
		}
	});
	hg.cons.Computer = function Computer (name) {
		var props = {};
		if (! name) { name = "localhost"; }
		if (! computers[name]) { return null; }
		this.name = name;
		this.location = typeof addresses[name] == "function" ? 
			addresses[name]() : addresses[name];
		this.pwd = "/";
		$.each(computers[name], function (property, value) {
			props[property] = value;
		});
		this.properties = props;
	};
	hg.network.ping = function (location) {
		var isInWeb = addresses[location] || addresses[dnsTable[location]],
			localLocation = hg.state.computer.location + ">" + location,
			isLocal = addresses[localLocation];
		return isInWeb || isLocal;
	};

})(jQuery, HackerGame); 


/**

HackerGame

**/
(function ($, hg) {
	var toText = function (input) {
			var output = "";
			if (typeof input == "object") {
				$.each(input, function (_, x) {
					output += x + "\n";
				});
			}
			else {
				output = input;
			}
			return output;
		},
		commands = {
			"ping": {
				exec: function (loc, num, ttl) {
					var term = this, step, dataString, status, time, 
						responseTime, responseTimeLong, responseTimeShort,
						i = 0,
						timeInSeconds = 1,
						isAvailable = hg.network.ping(loc),
						numOfSuccess = 0,
						timeSuma = 0; 
					if (! num) { num = 5; }
					if (! ttl) { ttl = 60; }
					responseTimeLong = hg.util.randResponseTime(3, ttl*1000);
					responseTimeShort = hg.util.randResponseTime(3, ttl*10);
					responseTime = function () { 
						return Math.random() > 0.2 ? 
							responseTimeShort() : responseTimeLong();
					};
					time = responseTime();
					term.pause();
					step = function () {
						timeSuma += time;
						var proc, stats, continueStep;
						status = isAvailable && Math.random() > 0.05;
						if (status) { numOfSuccess += 1; }
						
						continueStep = function () {
							dataString = "icmp_seq=" + (i + 1) 
								+ " ttl="+ttl+" time=" 
								+ (status ? (time/1000) : ttl) + " ms";
							term.echo("Pinging " + loc + " ... " + dataString + " " + (status ? "OK" : "LOST"));
							i += 1;
							if (i < num) {
								time = responseTime();
								setTimeout(step, timeInSeconds*1000 + time/1000); 
							}
							else {
								proc = ((num-numOfSuccess)/num*100);
								proc = Math.round(proc * 1000)/1000;
								stats = num + " packets transmited, " + numOfSuccess 
									+ " recieved, " 
									+ proc + "% pacet loss, time " + timeSuma;
								term.echo("\n--- " + loc + " ping statistics ---");
								term.echo(stats);
								term.resume();
							}
						};
						if (!status) {
							time += ttl*1000 - time/1000;
							setTimeout(continueStep, ttl*1000 - time/1000);
						}
						else {
							continueStep();
						}
					};
					setTimeout(step, time/1000);
				},
				help: ["ping - send a ping package to remote computer", 
					   "Usage: ping IP|DOMAIN [NUMBER_OF_PINGS=5 [TIME_TO_LIVE=60]]",
					   "TIME_TO_LIVE is in seconds.",
					   "Linux: ping"]
			},
			"eval": {
				help: ["eval - execute a JavaScript command", 
					   "Usage: eval COMMAND"]
			},
			"export": {
				help: ["export - store a variable",
					   "Usage: export VARIABLE=VALUE",
					   "Linux: export VARIABLE=VALUE"]
			},
			"help": {
				exec: function(command) {
					var term = this,
						blackList = hg.state.computer.properties.commandBlackList;
					if (!command) {
						this.echo("Available commands: ");
						$.each(commands, function (cmnd, props) {
							if ($.inArray(cmnd, blackList) > -1) {
								return;
							}
							term.echo(props.help[0]);
						});
						this.echo("\nFor more information type: help COMMAND");
					}
					else if (commands[command]){
						this.echo(toText(commands[command].help));
					}
					else {
						this.error("No information on command " + command);
					}
				},
				help: ["help - display help information", 
					   "Usage: help COMMAND",
					   "Linux: man or COMMAND -h or COMMAND --help"]
			}
		};
	hg.commandCompletion = function (term, string, fn) {
		var candidates = [];
		$.each(commands, function (cmnd, _) {
			if (cmnd.substr(0, string.length) == string) {
				candidates.push(cmnd);
			}
		});
		fn(candidates);
	};
	hg.exec = function(input, term) {
		var segments = input.split(" "),
			fn = segments[0],
			result,
			noError = true,
			attributes = segments.length > 1 ? segments.slice(1) : null;
		if ($.inArray(fn, hg.state.computer.properties.commandBlackList) > -1) {
			noError = false;
			term.error("Command is not defined!");
		}
		else if (commands[fn] && commands[fn].exec) {
			commands[fn].exec.apply(term, attributes);
		}
		else if(fn === "eval" || fn === "export") {
			if (attributes) {
				try {
					result = window.eval(attributes.join(" "));
					if (result !== undefined) {
						term.echo(new String(result));
					}
				} catch(e) {
					term.error(new String(e));
            	}
			}
		}
		else {
			noError = false;
		}
		if (noError && hg.callback) {
			// Callback is the main task checker.
			// If the input passes the callback
			// You can move to the next task
			var callbackResult = hg.callback.call(term, input),
				status;
			if (callbackResult) {
				status = hg.state.assignment.nextTask();
				if (! status) {
					hg.state.assignment.complete();
				}
			}
		}
		
	};
})(jQuery, HackerGame);

/**

HackerGame

**/
(function ($, hg) {
	var temp, 
		loadAssignment = function (assId, callback) {
			var htmlUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".html",
				htmlLangUrl = hg.config.basePath + hg.config.assignmentsPath + assId + "-" + hg.lang + ".html",
				loadJS = function (html) {
					$("#stash").html(html);
					$.getScript(jsUrl, callback);
				},
				jsUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".js";
			$.ajax({
				url: htmlLangUrl,
				method: 'get',
				dataType: 'html',
				success: loadJS,
				error: function() {
					// If no language markup file exists, load the default (english) file
					$.ajax({
						url: htmlUrl,
						method: 'get',
						dataType: 'html',
						success: loadJS
					});
				}
			});
		};
	hg.cons.State = function State(computer, config) {
		this.computer = computer || new hg.cons.Computer(hg.config.defaultComputer);
		this.innerState = undefined;
		if (config && typeof config === "object") {
			$.each(config, function (property, value) {
				this[property] = value;
			});
		}
	};
	hg.cons.Task = function Task(taskObj, taskHtml) {
		this.id = taskObj.id || null;
		this.isFinished = taskObj.isFinished || function () { return true; };
		this.set = taskObj.set || function () {};
		this.unset = taskObj.unset || function () {};
		this.points = taskObj.points;
		this.html = taskHtml || "";
	};
	hg.cons.Task.prototype.switchTask = function (previousTask) {
		var li = $(document.createElement("li")).attr("id", "task-" + this.id);
		if (previousTask) { 
			previousTask.unset(); 
			$("#task-" + previousTask.id).css("text-decoration", "line-trough");
		}
		this.set();
		$(li).html(this.html);
		$("#tab-task ul").append(li);
		hg.callback = this.isFinished;
	};
	hg.cons.Assignment = function Assignment(assignment, loadCallback) {
		this.currentTask = -1;
		this.numOfTasks = 0; // set with array length
		this.tasks = []; // array of task objects 
		this.isRunning = false;
		this.startTime = 0;
		loadAssignment(assignment, loadCallback);
	};
	hg.cons.Assignment.prototype.startTimer = function () {
		hg.timer.start(this.startTime);
	};
	hg.cons.Assignment.prototype.nextTask = function () {
		var nextTask,
			status=false,
			prevTask = this.currentTask > 0 ? this.tasks[currentTask] : undefined;
		if (this.currentTask < this.numOfTasks) {
			nextTask = this.tasks[this.currentTask + 1];
			nextTask.switchTask(prevTask);
			this.currentTask += 1;
			status = true;
		}
		hg.stats.refresh();
		return status;
	};
	hg.cons.Assignment.prototype.fail = function () {
		hg.timer.stop();
	};
	hg.cons.Assignment.prototype.complete = function () {
		hg.timer.stop();
	};
	hg.stats = {
		refresh: function() {
			var overallAssignments = hg.config.assignments.length,
				tasksInAssignment = hg.assignment.tasks.length;

			$("#stats-completed-tasks").text(hg.stats.completedTasks + "/" + tasksInAssignment);
			$("#stats-completed-assignments").text(hg.stats.completedTasks + "/" + overallAssignments);
			$("#stats-current-score").text(hg.stats.currentScore);
			$("#stats-best-score").text(hg.stats.bestScore);
			$("#stats-overall-score").text(hg.stats.overallScore);
		},
		increment: function(stat, val, hold) {
			if (hg.stats[stat]) { hg.stats[stat] += val; }
			if (! hold) { hg.stats.refresh(); }
		},
		completedAssignments: 0,
		completedTasks: 0,
		bestScore: 0,
		currentScore: 0,
		overallScore: 0
	};

	// Actions (which user can do)
	hg.action.page = function (pageId) {
		var prevPageId = $("#page-links .active").attr("id").substr(10),
			pageDisabled = $("#link-page-" + pageId).is(".disabled"),
			showPage = function () {
				$("#link-page-" + pageId).addClass("active"); 
				$("#page-" + pageId).show("slow");
			};
		if (pageDisabled) { return; }
		if (prevPageId) { 
			$("#link-page-" + prevPageId).removeClass("active"); 
			$("#page-" + prevPageId).hide("slow", showPage);
		}
		else {
			showPage();
		}
	};
	hg.action.input = function (inputId) {
		var prevInputId = $("#input-links .active").attr("id").substring(11),
			showInput = function () {
				$("#link-input-" + inputId).addClass("active"); 
				$("#input-" + inputId).show(0);
			};
		if (prevInputId) {
			$("#link-input-" + prevInputId).removeClass("active"); 
			$("#input-" + prevInputId).hide(0, showInput);
		}
		else {
			showInput();
		}
	};
	hg.action.tab = function (tabId) {
		var prevTabId = $("#tab-links .active").attr("id").substring(9),
			showTab = function () {
				$("#link-tab-" + tabId).addClass("active"); 
				$("#tab-" + tabId).show(0);
			};
		if (prevTabId) {
			$("#link-tab-" + prevTabId).removeClass("active"); 
			$("#tab-" + prevTabId).hide(0, showTab);
		}
		else {
			showTab();
		}
	};
	hg.action.assignment = function (assId) {
		var status = hg.load.assignment(assId);
		if (status) {
			$("#link-tab-game").removeClass("disabled");
		}
	};
	hg.action.mail = function (cmnd) {
		if (cmnd == "open") { hg.mail.open(); }
	};
})(jQuery, HackerGame);

