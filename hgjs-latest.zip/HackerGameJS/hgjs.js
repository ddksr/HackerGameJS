/*

HackerGame default javascript file

*/
HackerGame = {};

(function ($, hg) {
	// ===========================================
	// Internal objects and methods initialization
	// ===========================================
	var i18n, // language object
		/**
		 * core: initAssignment ()
		 *
		 * Initialize loaded assignment. 
		 * Switch to Game page. 
		 **/
		initAssignment = function () { // Prepare assignment

			$("#link-page-game").removeClass("disabled");
			hg.action.page("game");
			hg.action.tab("assignment");
			$("#tab-tasks li").hide();
		},
		/**
		 * core: startAssignment ()
		 * 
		 * Start assignment (time courting, command line evaluation ...).
		 **/
		startAssignment = function () { // Start workign on assignment
			hg.assignment.startCallback();
			hg.stats.refresh();
			hg.assignment.isRunning = true;
			hg.assignment.nextTask();
			hg.assignment.startTimer();

			$("#tab-tasks li").show();

			hg.action.tab("task");

			$("#tab-task").scrollTop(0);

		},
		/**
		 * core: initDynamicFields ([selector])
		 * - selector : string - jQuery selector string
		 * 
		 * Go trough selector or body and replace dynamic fields with associated values.
		 **/
		initDynamicFields = function (selector) {
			$((selector || "body") + " .dyn").each(function () {
				var field, attr = $(this).attr("data-field");
				if (attr) {
					attr = attr.split(".");
					if (attr.length > 1) {
						field = hg.config;
						$.each(attr, function (_, elt) {
							field = field[elt] || {};
						});
					}
					if (field) {
						$(this).text(field);
					}
				}
			});
		},
		/**
		 * core: initTaskHTML ($task)
		 * - $task : jQuery object - task HTML
		 * 
		 * Initialize task HTML. Convert hits and help to buttons etc.
		 **/		 
		initTaskHTML = function ($task) {
			var $help, $hint, 
				$btn = $(document.createElement("button")).addClass("btn").addClass("btn-info").addClass("btn-sm");
			$("#tab-task .tasks-list").append($task.append($(document.createElement("br"))));

			$task.addClass("future-task");

			$help = $task.find(".help").clone();
			$hint = $task.find(".hint").clone();
			
			if ($help.length > 0) {
				$task.find(".help").replaceWith($btn.clone().addClass("help").text("Help").popover({
					content: $help.html(),
					title: hg.t("Help"),
					placement: "top",
					html: true
				}));
			}
			if ($hint.length > 0) {
				$task.find(".hint").replaceWith($btn.clone().addClass("hint").text("Hint").popover({
					content: $help.html(),
					title: hg.t("Hint"),
					placement: "bottom",
					html: true
				}).on('shown.bs.popover', function () {
					hg.assignment.queue.push("hint");
				}));
			}
		},
	

		/**
		 * core: baseInit ([settings])
		 * - settings : object - settings objects to overwrite config
		 *
		 * This is the base initialization. It initializes the terminal
		 * and assignments. It has to be called right after the page loads and
		 * before any server scripts or similar are loaded.
		 **/
		baseInit = function(settings) {
			var $obj = this,
				tOut = function (text) {
					var out = "";
					if (! $.isArray(text)) {
						text = [text];
					}
					$.each(text, function (_, str) {
						out += hg.t(text);
					});
					return out;
				};
			hg.config = $.extend(hg.config, settings);

			hg.config.terminal.completion = hg.commandCompletion;
			hg.config.terminal.prompt = function (fn) {
				var comp = hg.state.computer,
					props = comp.properties,
					user = props.user,
					dir = (comp.pwd == "/" && "/") || null,
					hostname = (comp.fs.etc && comp.fs.etc.hostname) || props.hostname;
				if (!dir) {
					dir = comp.pwd;
					if (dir == ("/home/"+user)) {
						dir = "~";
					}
					else {
						dir = dir.split("/");
						dir = dir[dir.length-1];
					}
				}
				fn("[" + user + "@" + hostname.split("\n")[0] + " " + dir + "]$ ");
			};

			$("#anon-sama").popover();

			// This is where it has to be. There is an error alerted in FF if
			// This is moved one command lower. 
			hg.state = new hg.cons.State();

			hg.term = $obj.terminal(hg.exec, hg.config.terminal);
			
			hg.tEcho = function (text) {
				hg.term.echo(tOut(text));
			};
			hg.tError = function (text) {
				hg.term.error(tOut(text));
			};
			
			// Initialize available task list
			$.each(hg.config.assignments, function (i, ass) {
				var assNum = 0,
					$tr = $(document.createElement("tr")),
					$tdName = $(document.createElement("td")),
					$tdCurrent = $(document.createElement("td")).addClass("ass-current-score"),
					$tdBest = $(document.createElement("td")).addClass("ass-best-score"),
					$tdTrials = $(document.createElement("td")).addClass("ass-trials"),
					$a = $(document.createElement("a"));
				
				if (ass && typeof(ass) == "object") {
					$tr.addClass("assignment")
						.addClass("ass-" + ass.id)
						.attr("data-id", ass.id);

					$a.attr("href", "#/assignment/" + ass.id).text(hg.t(ass.name));
					$tdName.addClass("ass-name").append(" - ").append($a);
					
					$tdCurrent.text("-");
					$tdBest.text("-");
					$tdTrials.text("0");

					hg.ind.NUM_OF_ASSIGNMENTS += 1;
					$tr.append($tdName).append($tdCurrent).append($tdBest).append($tdTrials);

				}
				else {
					$tdName.text(hg.t(ass))
						.addClass("assignment-separator")
						.attr("colspan", 4);
					$tr.append($tdName);
				}
				$("table.assignment-list").append($tr);
				
			});
			return $obj;
		},
		/**
		 * core: contentInit
		 * 
		 * Content initialization (translations evaluated and loading image removed).
		 * Note: has to be called after baseInit and after any server scripts are loaded.
		 **/
		contentInit = function () {

			hg.refreshTranslations();

			hashChange(null);

			$("body").removeClass("loading");
		},
		/**
		 * core: hashChange (evt)
		 * - evt : object - event object
		 * 
		 * Event function which listens to hash changes.
		 **/
		hashChange = function (evt) { // event listener for hash changing
			var hash = window.location.hash,
				segments = hash ? hash.split("/") : [],
				command, args;
			if (evt) { evt.preventDefault(); }
			if (segments.length > 1) {
				command = segments[1];
				if (command && hg.action[command]) {
					args = segments.slice(2);
					args = args || [];
					hg.action[command].apply(this, args);
				}
				window.location.hash = "";
			}

		};


	// =========================
	// Containers initialization
	// =========================

	hg.cons = {}; // constructors
	hg.cli = {}; // CLI methods
	hg.network = {}; // network methods
	hg.util = {}; // utility methods
	hg.action = {}; // action methods
	hg.include = {}; // includer object, called from assignments
	hg.dump = {}; // packer object
	hg.editor = {}; // editor methods
	hg.load = {}; // load methods
	hg.ind = {}; // indicators module
	hg.stats = {}; // stats module
	hg.msg = {}; // mesages

	// ==============
	// Public methods
	// ==============

	// Terminal methods

	/**
	 * hg.term
	 *
	 * Terminal object
	 **/
	hg.term = null;

	/**
	 * hg.tEcho (string)
	 * - text : string
	 * 
	 * Echo the text in the terminal.
	 * It also translates the text if possible.
	 **/
	hg.tEcho = function () {};

	/**
	 * hg.tError (text)
	 * - text : string
	 * 
	 * Echo the text in the terminal as an error.
	 * It also translates the text if possible.
	 **/
	hg.tError = function () {};


	/**
	 * hg.t (string)
	 * - string : string - translation key
	 *
	 * The 'string' gets translated if possible.
	 **/
	hg.t = function (string) {
		return (i18n && i18n[string]) || string;
	};

	/**
	 * hg.refreshTranslations ([selector])
	 * - selector : string - jQuery selector string
	 * 
	 * Refresh body or selector translations.
	 **/
	hg.refreshTranslations = function (selector) {
		selector = selector ? (selector + " ") : "";
		$(selector + ".i18n").each(function () {
			var defaultString = $(this).attr("data-lang"),
				hasKey = i18n && i18n[defaultString],
				data = $(this).data("translation"),
				text = hg.t(defaultString);
			if ($(this).is(".text")) {
				// If the i18n element also has the text chass
				// is is asumed that the key would be very long
				// so short keys are also supported.
				// If the t() returns the same key, we know that the
				// Translation didn't happen so wi don't overwrite the text
				if (hasKey) {
					// We store the previous translation so that
					// translations can be switched but only the first time
					// when data is false
					if (hasKey && !data) { 
						$(this).data("translation", $(this).html());
					}
					$(this).html(text);
				}
				else if (data) {
					$(this).html(data);
				}
			}
			else { $(this).html(text); }
		});
	};

	/**
	 * hg.msg.alert (message, [title])
	 * - message : string
	 * - title : string - title string
	 *
	 * Display alert dialog with 'message' as message body and 'title'
	 * as dialog title. If no title is specified, 'Alert' will be used
	 **/
	hg.msg.alert = function (message, title) {
		if (! title) { title = "Alert"; }
		$("#alertMessageTitle").text(hg.t(title));
		$("#alert .modal-body").html(hg.t(message));
		$("#alert").modal("show");
	};

	// Loader (assignments and languages)
	hg.load = {
		/**
		 * hg.load.assignment (tasks, other)
		 * - tasks : array - contains tasks objects
		 * - other : object - other important information
		 
		 * Object in 'tasks' array should contain:
		 * - evaluate : function - evaluation function
		 * - id : string - task id
		 * - set : function - callback before task is initialized
		 * - unset : function - callback after the task is completed
		 * - points : number - number of points this task can bring
		 *
		 * Object 'other' must contain:
		 * - startTime : number - number of seconds available for assignment, if 0 then unlimited
		 *
		 * Object 'other' can contain:
		 * - startMail : boolean - show email before assignment starts
		 * - successCallback : function - callback if assignment successfully completed
		 * - failCallback : function - callback if assignment fails
		 * - startCallback : function - callback after assignment is started (Start button)
		 * - initCallback : function - callback after assignment is initialized
		 * 
		 * Method loads the assignment into the game, prepares the tasks
		 * Resets the stats, etc.
		 *
		 * THIS SHOULD BE CALLED FROM ASSIGNMENT SCRIPTS
		 **/
		assignment: function (tasks, other) {
			var msgBody, title, $heading, $instructions, $tasksHtml, $learnMore, $tryItOut;

			initDynamicFields();
			
			// Button is hidden after assignment is started
			// So to enable solving more than one assignment per session
			// we have to show the button again
			$("#button-start-game").show();
			

			title = $("#stash").find("#ass-title").text();
			$heading = $(document.createElement("h2")).append(hg.t(title));
			msgBody = $("#stash").find("#ass-greeting").html();
			$instructions = $("#stash").find("#ass-instructions").clone();
			$tasksHtml = $("#stash").find("#ass-tasks").clone();
			$learnMore = $("#stash").find("#ass-learn-more").clone();
			$tryItOut = $("#stash").find("#ass-try-it-out").clone();

			// Init stats
			hg.assignment.numOfTasks = tasks.length;
			
			hg.assignment.startTime = other.startTime;
			
			hg.timer.set(other.startTime, function () {
				hg.assignment.fail();
			});
			

			hg.stats.bestScore = $(".assignment-list .ass-" + hg.assignment.id + " .ass-trials").text();
			hg.stats.currentScore = 0;
			hg.stats.refresh();


			// Parse HTML
			$("#tab-assignment .instructions").html($instructions).prepend($heading);
			$("#tab-task").html($(document.createElement("ol")).addClass("tasks-list"));
			$("#tab-learn-more").html($learnMore);
			$("#tab-try-it-out").html($tryItOut);

			$.each(tasks, function (i, task) {
				var html = $tasksHtml.find("." + task.id).html(),
					$li = $(document.createElement("li")).attr("id", "task-" + task.id);
				
				hg.assignment.tasks[i] = new hg.cons.Task(task);

				$li.html(html);
				initTaskHTML($li);
			});
			$("#stash").empty();

			hg.assignment.successCallback = other.successCallback || function () {};
			hg.assignment.failCallback = other.failCallback || function () {};
			hg.assignment.startCallback = other.startCallback || function () {};
			hg.assignment.initCallback = other.initCallback || function () {};

			
			if (other.startMail) {
				hg.mail.recieve({
					subject: title,
					isSensei: true,
					body: msgBody,
					button: {
						name: "Start",
						action: function () { 
							hg.mail.close();
							initAssignment();
							hg.assignment.initCallback();
						}
					}
				});
				$("#mail").popover("show");
			}
			else {
				initAssignment();
				hg.assignment.initCallback();
			}
		},
		/**
		 * hg.load.externalFile (internalFilePath, externalFilePath)
		 * - internalFilePath : string - internal file path to new file
		 * - externalFilePath : string - external file path to file that will be loaded
		 *
		 * Load external file as text with AJAX into the filesystem as a text file.
		 **/
		externalFile: function (internalFilePath, externalFilePath) {
			$.ajax({
				url: externalFilePath,
				async: false,
				dataType: "text",
				success: function (content) {
					hg.util.setFile(internalFilePath, content);
				},
				error: function (a,b) {
				}
			});
		},
		/**
		 * hg.load.language (languageId, languageObject)
		 * - languageId : string - language id
		 * - languageObject : object - contains translations in form english: translated
		 *
		 * Load language object to the game. Doesn't run hg.refreshTranslations()
		 **/
		language: function (langId, langObj) {
			if (typeof(langId) == "object") { langObj = landId; }
			else if (langObj) { hg.lang = langId; }
			i18n = $.extend(i18n, langObj);

		},
		/**
		 * hg.load.specialFile (path, content)
		 * - path : string - internal path to file
		 * - content : function (input) - function which takes one argument
		 *
		 * Method for loading special files. Special file is represented in
		 * filesystem as a binary object, but its logic ('conent') gets
		 * loaded into the dynamic fielsystem (DFS).
		 * 
		 * The content function must return an array in the form:
		 * [status, string]
		 * - status : boolean - if the input was correct
		 * - string : string - the return string
		 **/
		specialFile: function (path, content) {
			if (! $.isFunction(content)) { return null; }
			hg.util.setFile(path, null);
			hg.state.computer.dfs[path] = content;
		}
	};

	// Indicators
	/**
	 * hg.ind
	 *
	 * Indicator object. Cosits of global states and constants.
	 * - modal : boolean - is there a modal dialog displayed
	 * - NUM_OF_ASSIGNMENTS - number of assignments
	 **/
	hg.ind = {
		modal: false,
		NUM_OF_ASSIGNMENTS: 0
	};

	// Mail system
	hg.mail = {
		message: undefined, // string message
		/**
		 * hg.mail.setNew ()
		 *
		 * Call to set the mail icon red.
		 **/
		setNew: function() {
			if (!$("#mail").is(".red-alert")) {
				$("#mail").addClass("red-alert");
			}
			$("#mail").hgBlink();
		},
		/**
		 * hg.mail.setEmpty ()
		 * 
		 * Call to set the mailbox icon as empty.
		 **/
		setEmpty: function () {
			$("#mail").removeClass("red-alert");
		},
		/**
		 * hg.mail.recieve (message, clickOpen)
		 * - message : object
		 * - clickOpen : function - callback when mail is opened
		 * 
		 * Object 'message' must contain:
		 * - body : string - message body
		 * Object 'message' can contain:
		 * - sender : string - sender name
		 * - isSensei : boolean - if true, message will be treated more importantly
		 * - button : object - object for mail button
		 *
		 * Object 'button' must contain:
		 * - name : string - button title
		 * - action : function - callback when button is clicked
		 **/
		recieve: function (message, clickOpen) {
			hg.mail.message = {
				sender: message.isSensei ? "sensei" : (message.sender || "anon"),
				isSensei: message.isSensei,
				body: message.body,
				button: message.button || null
			};
			hg.mail.setNew();
		},
		/**
		 * hg.mail.open ()
		 * 
		 * Message dialog box initialization after mail icon is clicked.
		 **/
		open: function () {
			var img, button, title;
			if (hg.mail.message && ! hg.ind.modal) {
				img = hg.mail.message.isSensei ? "anon-small" : "any";
				img = hg.config.basePath + hg.config.imagesPath + img + ".png";
				title = hg.t("Message from <strong>" + hg.mail.message.sender + "</strong>");
				$("#mailIcon").attr("src", img).css({
					display: "block",
					margin: "5px auto 0px auto"
				});
				$("#mailMessage .body").html(hg.mail.message.body);
				$("#mailMessage .modal-title").html(title);
				$("#mailMessage").modal("show").on("hide.bs.modal", function () {
					hg.ind.modal = false;
				});
				if (hg.mail.message.button) {
					$("#mailButton").text(hg.mail.message.button.name)
						.click(hg.mail.message.button.action).show();
				}
				else {
					$("#mailButton").hide();
				}
				hg.ind.modal = true;
			}
			$("#mail").popover("hide");
			hg.mail.setEmpty();
		},
		/**
		 * hg.mail.close()
		 *
		 * Close message dialog.
		 **/
		close: function () {
			$("#mailMessage").modal("hide");
			hg.ind.modal = false;
		}
	};
	
	// ==============
	// jQuery plugins
	// ==============

	/**
	 * jQuery: .hackerGame([settings])
	 * - settings : object - object to overwrite configuration
	 * 
	 * Make DOM object into the game terminal
	 **/
	$.fn.hackerGame = function (settings) {
		var $termObj = this;
		baseInit.call($termObj, settings);
		if (settings && settings.server) {
			hg.initServer = function () {
				contentInit.call($termObj);
			};
			$.getScript(settings.server);
		}
		else {
			// Load saved state from CONFIG
			if (hg.config.state) { 
				hg.load.state({
					state: hg.config.state
				}); 
			}
			contentInit.call($termObj);
		}
		return $termObj;
	};

	/**
	 * jQuery: .hackerGameEditor([settings])
	 *
	 * Make DOM object into game Editor. Settings are currently not used.
	 **/
	$.fn.hackerGameEditor = function (settings) {
		var $edtObj = this, 
			filePath = null, 
			filename=null,
			editable = false,
			special = false;

		/**
		 * hg.editor.enable ()
		 * 
		 * Enable Editor
		 **/
		hg.editor.enable = function () {
			$($edtObj).attr("contentEditable", "true");
		};

		/**
		 * hg.editor.disable ()
		 * 
		 * Disable Editor
		 **/
		hg.editor.disable = function () {
			$($edtObj).attr("contentEditable", "false");
		};

		
		/**
		 * hg.editor.getContent ()
		 * 
		 * Get Editor content
		 **/
		hg.editor.getContent = function () {
			var content = $($edtObj).html().replace(/<br>/g, "\n");
			if (content.charAt(content.length - 1) == '\n') {
				content = content.substr(0, content.length - 1);
			}
			return content;
		};

		/**
		 * hg.editor.setContent ()
		 * - content : string - content to be set
		 * 
		 * Set editor content.
		 **/
		hg.editor.setContent = function (content) {
			$($edtObj).html(content.replace(/\n/g, "<br>"));
		};

		/**
		 * hg.editor.focus ()
		 * 
		 * Focus Editor (switch to Editor tab)
		 **/
		hg.editor.focus = function () {
			hg.action.input("editor");
		};

		/**
		 * hg.editor.blur ()
		 * 
		 * Blur Editor (switch to Terminal tab)
		 **/
		hg.editor.blur = function () {
			hg.action.input("terminal");
		};

		/**
		 * hg.editor.watch (path, specialInput)
		 * - path : string - path to file to watch
		 * - specialInput : string - optional special input for special files
		 * 
		 * Watch text or special file in editor. If not special, the file
		 * get editable.
		 **/
		hg.editor.watch = function (path, specialInput) { // TODO: rewrite, now you can!
			var fileData,
				specialMeta = null;
			editable = true;
			if (hg.util.fileExists(path)) {
				fileData = hg.util.getFile(path);
				if (fileData[3] == "b" && specialInput) {
					specialMeta = hg.util.getSpecialFile(fileData[0] + fileData[1])(specialInput);
					if (specialMeta !== null) {
						if (specialMeta[0]) {
							fileData[2] = specialMeta[1];
							editable = false;
						}
						else {
							return specialMeta[1];
						}
					}
					else {
						return "File is not a text file.";
					}
				}
				else if (fileData[3] != "t") {
					return "File is not a text file.";
				}
			}
			else {
				// create file
				fileData = hg.util.setFile(path, "");
				if (fileData) {
					fileData = hg.util.getFile(path);
				}
				else { return "Path doesn't exist."; }
			}
			hg.editor.setContent(fileData[2]);
			filePath = fileData[0];
			filename = fileData[1];
			
			$("#button-save-editor").attr("disabled", !editable);
			$("#button-close-editor").attr("disabled", false);
			if (editable) { hg.editor.enable(); }

			return false;
		};

		/**
		 * hg.editor.unwatch ()
		 *
		 * Unwatch current file.
		 **/
		hg.editor.unwatch = function () {
			$("#button-save-editor, #button-close-editor").attr("disabled", true);
			if ($.isFunction(hg.editor.closeCallback)) {
				hg.editor.closeCallback();
			}
			filePath = null;
			hg.editor.setContent("");
			hg.editor.disable();
			
			hg.editor.openCallback = null;
			hg.editor.closeCallback = null;
		};

		/**
		 * hg.editor.save ()
		 *
		 * Save contents to watch file (this overwrites special fies !!!)
		 **/
		hg.editor.save = function () { // FIXME: don't overwrite special files
			var message = hg.t("File") + " " + filePath + filename + " " + hg.t("saved") + ".";
			if (! editable) {
				return;
			}
			
			hg.util.setFile((filePath + filename), hg.editor.getContent());
			

			hg.state.computer.hasChanged = true;
			$("#editor-message").hide().text(message).fadeIn("slow", function () {
				setTimeout(function () {
					$("#editor-message").fadeOut("slow").text("");
				}, 2000);
			});
		};

		$("#button-save-editor").click(function () {
			hg.editor.save();
			$(this).blur();
		});
		$("#button-close-editor").click(function () {
			$(this).blur();
			hg.editor.unwatch();
			
			hg.editor.blur();
		});
		return $edtObj;
	};

	/**
	 * jQuery: .hackerGameTimer()
	 *
	 * Initialize hackergame timer.
	 **/
	$.fn.hackerGameTimer = function() {
		var $obj = this,
			ms = 1000, // number of ms to trigger
			zeroTimeCallback, // callback when timer is finised 
			// Display timer (called everytime step is called)
			display = function(noCounting) {
				minutes = Math.floor(hg.timer.counter/60);
				seconds = hg.timer.counter - minutes*60;
				minutes = (minutes < 10 ? "0" : "") + minutes;
				seconds = (seconds < 10 ? "0" : "") + seconds;
				if (!noCounting && hg.timer.counter <= 60 && !$obj.is(".red-alert")) {
					$obj.addClass("red-alert");
				}
				if (!noCounting) { 
					$obj.text(minutes + ":" + seconds); 
				}
				else {
					$obj.text("--:--");
				}
			},
			// Step called every second
			step = function () {
				var minutes, seconds;
				hg.timer.counter -= 1;
				display();
				if (isNaN(hg.timer.counter) || hg.timer.counter <= 0) { 
					zeroTimeCallback();
					return; 
				}
				hg.timer.status = setTimeout(step, ms);
			};
		hg.timer = {
			/**
			 * hg.timer.counter
			 *
			 * Integer field containing remaining number of seconds.
			 **/
			counter: 0, 
			
			/**
			 * hg.timer.lastCounter
			 * 
			 * Stores the last counter value if timer was stopped before counter was zero.
			 **/
			lastCounter: null,
			
			/**
			 * hg.timer.status
			 *
			 * Stores the timeout value.
			 **/
			status: undefined,
			
			/**
			 * hg.timer.set (setCounter, ztCallback)
			 * - setCounter : integer - counter value
			 * - ztCakkbacj ; function - callback called when counter gets to 0
			 * 
			 * Initialize and set the timer.
			 **/ 
			set: function (setCounter, ztCallback) {
				if ($obj.is(".red-alert")) {
					$obj.removeClass("red-alert");
				}
				this.counter = setCounter;
				
				zeroTimeCallback = ztCallback || function () {};
				display(setCounter === 0);
			},

			/**
			 * hg.timer.start
			 *
			 * Start counting.
			 **/
			start: function () {
				hg.timer.status = setTimeout(step, ms);
			},

			/**
			 * hg.timer.stop
			 *
			 * Stop counting. Stop callback doesn't get called.
			 **/
			stop: function () {
				this.lastCounter = this.counter;
				this.counter = 0;
				if (this.status) { clearTimeout(this.status); }
			}
		};
		return this;
	};

	// ===================
	// HTML initialization
	// ===================

	$("body").addClass("loading");
	$("body").append($(document.createElement("div")).addClass("loading-gif").html("&nbsp;"));


	$("#alert").modal();

	$.each(["tab", "input", "page"], function(i, segment) {
		var offset = 6 + segment.length;
		$("#" + segment + "-links").find("li").each(function () {
			if (! $(this).attr("id")) { return; }
			var isSelected = $(this).is(".active"),
				id = $(this).attr("id").substr(offset);
			if (! isSelected) {
				$("#" + segment + "-" + id).hide();
			}
		});
	});
	$("#mailMessage").modal().on("hide.bs.modal", function () {
		hg.ind.modal = false;
	});
	
	$("#mail").popover({
		content: hg.t("You have mail! Click to continue"),
		trigger: "manual",
		placement: "bottom"
	});
	$("#mail").click(function () {
		hg.mail.open();
	});
	$("#button-start-game").click(function () {
		$(this).hide();
		startAssignment();
	});
	
	// ==============
	// Event listenrs
	// ==============
	$(window).on('hashchange', hashChange);
	
})(jQuery, HackerGame);

/*

HackerGame

*/
(function ($, hg) {
	var notValidIP = [10,127,254,255,1,2,169,172,192], // not vaild first ip numbers
		randIntGenerator = function (from, to) { // random integer generator
			if (!from) { from = 0; }
			if (!to) { to = 1; }
			return function () { return Math.round(Math.random()*(to-from)+from); };
		},
		fileTypes = { // possible file types
			"null": "b", 
			"object": "d",
			"string": "t"
		},
		fileTypesLong = { // long filetypes names
			"b": "binary",
			"d": "directory",
			"t": "text"
		};
	/**
	 * hg.util.randomChoice (array)
	 * - array : array
	 * 
	 * Return a random value in array.
	 **/
	hg.util.randomChoice = function(array) {
		var rand = randIntGenerator(0, array.length-1)();
		return array[rand];
	};


	/**
	 * hg.util.randomString (length, [lower])
	 * - length : int - length of random string
	 * - lower : boolean - if true, only lower letters
	 *
	 * Generate a random string.
	 **/
	hg.util.randomString = function(length, lower) {
		var genInt = randIntGenerator(0, 25), 
			genBool = randIntGenerator(0, 1),
			string = "", chr = "";

		while(length-- > 0) {
			chr = String.fromCharCode(97 + genInt());
			if (!lower && genBool() > 0) {
				chr = chr.toUpperCase();
			}
			string += chr;
		}
		return string;
	};
	
	/**
	 * hg.util.extend (default, over)
	 * - default : object - default object that gets overwritten
	 * - over : object - overwritting object
	 *
	 * Return: object
	 *
	 * This utility behaves a lot like $.extend but if it detects that both
	 * default[key] and over[key] are objects, it will recursively call itself
	 * upon them. 
	 */
	hg.util.extend = function (objDef, objOver) { 
		// TODO: check if you can replace with native jQuery's
		var obj = {};
		$.each(objDef, function (key, _) {
			if (! objOver[key]) {
				obj[key] = objOver[key] !== undefined ? objOver[key] : objDef[key];
			}
			else if (typeof(objDef[key]) == "object" && typeof(objOver[key]) == "object") {
				obj[key] = hg.util.extend(objDef[key], objOver[key]);
			}
			else  {
				obj[key] = objOver[key];
			}
		});
		return obj;
	};

	/**
	 * hg.util.parseInput (input)
	 * - input : string - user input from command line
	 * 
	 * Return: array
	 *
	 * Parse user input and return: [command, argsStr, args, rawArgsString]
	 * - command : string - user command
	 * - argsStr : string - parsed arguments as a string (removing ' and " )
	 * - args : array - parsed argumetns as array
	 * - rawArgsString : string - same as argsString but unprocessed
	 */
	hg.util.parseInput = function (input) {
		var segments = input.match(/(\w+) *(.*)/),
			argsString = "",
			rawArgsString = "",
			args = [],
			i = 0,
			n = 0,
			from = 0,
			to = 0,
			sep = null,
			chr,
			parseArg = function (trim) {
				// trim spaces before from
				while (trim && argsString.charAt(from) == ' ') {
					from++;
				}
				
				args.push(argsString.substring(from, to));
				from = to + 1;
				if (from > n) { from = n; }
				sep = null;
			},
			command = null;
		if (segments !== null) {
			command = segments[1];
			argsString = segments[2];
			n = argsString.length;

			while (i < n) {
				chr = argsString.charAt(i);
				to = i;
				if (chr == '\'' || chr == '"') { // char can be a seperator
					if (sep) {
						if (chr === sep) { // seperator close
							parseArg();
							i = i+1; // jump over
						}
						// else do nothing: chr is just a char between two seperators
					}
					else { // seperator start
						sep = chr;
						from = i + 1;
					}
				}
				else if (!sep && chr == ' ') {
					parseArg(true);
				}
				i++;
			}
			if (sep) {
				// This must not happen, if the input is false
				// report to calling function
				return [command, null, null, argsString];
			}
			if (argsString.length == 1) {
				return [command, argsString, [argsString], argsString];
			}
			if (from < i && from <= to) {
				to = i;
				parseArg(true);
			}
			rawArgsString = argsString;
			argsString = args.join(" ");
		}
		else { 
			command = input;
		}
		return [command, argsString, args, rawArgsString];
	};


	/**
	 * hg.util.randIP ()
	 * 
	 * Return: string
	 *
	 * Generate random IP address.
	 */
	hg.util.randIP = function () {
		var generator = randIntGenerator(1,255), first = generator();
		while ($.inArray(first, notValidIP) > -1) { first = generator(); }
		return [first, generator(), generator(), generator()].join(".");
	};

	/**
	 * hg.util.randResponseTime (from, to)
	 * - from : integer
	 * - to : integer
	 * 
	 * Return: function
	 *
	 * Return generator for random response time.
	 */
	hg.util.randResponseTime = function(from, to) {
		return randIntGenerator(from, to);
	};

	/**
	 * hg.util.fileType (file, [longName])
	 * - file: mixed - file content
	 * - longName : boolean - if true, long filetype name will be returned
	 *
	 * Return: string
	 *
	 * Return filetype with respect to file content.
	 * Types:
	 * - b: binary ( can also be special! )
	 * - d: directory
	 * - t: text
	 */
	hg.util.fileType = function (file, longName) {
		var type = (file === null && fileTypes["null"]) || fileTypes[typeof(file)];
		return longName ? fileTypesLong[type] : type;
	};

	/**
	 * hg.util.path = function ([rawPathString])
	 * - rawPathString : string - raw path (relative, absolute ... )
	 *
	 * Return: array - path array
	 * 
	 * Return path array. If rawPathString isn't specified, PWD will be used.
	 * Absolute path is prepended automatically.
	 * Example: /one/two -> ['one', 'two']
	 */
	hg.util.path = function (rawPathString) {
		var ret = null,
			pathString = (rawPathString && 
						  (rawPathString.charAt(rawPathString.length-1) == "/" ? // remove last /
						   rawPathString.substr(0, rawPathString.length-1) : rawPathString)) 
				|| null,
			pwdPath = hg.state.computer.pwd.split("/").slice(1),
			path = (pathString && pathString.split("/")) || [];

		if (hg.state.computer.pwd == "/") { pwdPath = []; }
		if (rawPathString == "/" || pathString == "/" || (!pathString && hg.state.computer.pwd == "/")) {
			ret = [];
		}
		else if (path) {
			if (pathString && pathString.charAt(0) == "/") {
				// absolute path
				ret = path.slice(1);
			}
			else if (!pathString) {
				// no rawPathString, just add pwdPath
				ret = pwdPath;
			}
			else {
				// combine current path (pwd) with path string
				ret = pwdPath.concat(path);
			}
		}
		return ret;
	};

	/**
	 * hg.util.checkFilePermission (absPath, [totalTest])
	 * - absPath : string - absolute path to file
	 * - totalTest : boolean - if true, path will be cleand and if relative, changed to absolute
	 * Return: boolean
	 *
	 * Check if wile is writtable.
	 */
	hg.util.checkFilePermission = function (absPath, totalTest) {
		if (totalTest) {
			if (absPath.charAt(0) != "/") {
				absPath = hg.util.absPath(absPath);
			}
			absPath = hg.util.cleanPath(absPath);
			return hg.util.checkFilePermission(absPath);
		}
		if (typeof(absPath) != "string" || absPath.charAt(0) !== "/") {
			return null;
		}
		return $.inArray(absPath, [
			"/",
			"/bin",
			"/home"
		]) == -1;
	};

	/**
	 * hg.util.fileExists (loc)
	 * - loc : string - location of file (filepath)
	 *
	 * Return: boolean
	 *
	 * Check if file exists. Note: directory is also a file!
	 */ 
	hg.util.fileExists = function (loc) {
		var ret = false;
		hg.util.pathIterator(loc, function (obj) {
			ret = obj !== undefined;
		});
		return ret;
	};

	/**
	 * hg.util.isDir (dir)
	 * - dir : string - directory filepath
	 * 
	 * Return: boolean
	 * 
	 * Check if file is directory. If file doesn't exists, false is returned
	 */
	hg.util.isDir = function (dir) {
		var ret = false;
		hg.util.pathIterator(dir, function (obj) {
			ret = typeof(obj) == "object" && obj !== null;
		});
		return ret;
	};

	/**
	 * hg.util.absPath (path)
	 * - path : string - relative path to file
	 * 
	 * Return: string
	 * 
	 * Create absolute path to file (this is a straightforward and stupid method, it just
	 * prepends PWD. Note: no checking if path is already absolute is done.
	 */
	hg.util.absPath = function (path) {
		return hg.state.computer.pwd + (hg.state.computer.pwd == "/" ? "" : "/") + path;
	};

	/**
	 * hg.util.cleanPath (path)
	 * - path : string - absolute or relative path
	 *
	 * Return: string
	 *
	 * Return cleaned path. Example: /one/two/../two2 -> /one/two2
	 */
	hg.util.cleanPath = function (path) {
		var returnPath = [], emptyPath, isAbs = path.charAt(0) == "/";
		if (path == "/") { return "/"; }
		if (path == ".") { return ""; }
		if (path.charAt(path.length - 1) == "/") { path = path.substr(0, path.length - 1); }
		$.each(path.split("/"), function (i, elt) {
			if (elt == ".") { return; }
			
			if (elt == "..") { 
				returnPath.pop(); 
				if (isAbs && returnPath.length == 0) { returnPath.push(""); }
			}
			else if(elt || i == 0) { returnPath.push(elt); }
		});

		emptyPath = returnPath.length == 0 || (returnPath.length == 1 && !returnPath[0]);
		return emptyPath ? "/" : returnPath.join("/");
	};

	/**
	 * hg.util.pathIterator (dir, fn)
	 * - dir : string : directory to iterate to
	 * - fn : function - callback
	 *
	 * Return: boolean
	 *
	 * Iterate trough path and call the callback function on the last
	 * directory that was iterated. Return true if everything OK, else false.
	 */
	hg.util.pathIterator = function (dir, fn) {
		var path = hg.util.path(dir),
			res = null,
			place = [hg.state.computer.fs],
			iterator = function (i) {
				if (i < path.length) {
					if (i == -1 || path[i] == ".") { 
						iterator(i+1); 
					}
					else {
						if (path[i] == "..") {
							place.pop();
							if (place.length == 0) {
								place = [hg.state.computer.fs];
							}
						}
						else {
							if (place[place.length-1] === undefined) {
								return false;
							}
							place.push(place[place.length-1][path[i]]);
						}
						iterator(i+1);
					}
				}
				else { fn(place[place.length-1]); }
			};
		if (path.length == 0) { fn(place[place.length-1]); }
		else if (path) { iterator(-1); }

		return true;
	};

	/**
	 * hg.util.getSpecialFile (path)
	 * - path : string - ABSOLUTE path to special file
	 *
	 * Return: function
	 *
	 * Get special file. If no special file exists, a function that when called
	 * returns null is generated.
	 */
	hg.util.getSpecialFile = function (path) {
		return hg.state.computer.dfs[path] || function () { return null; };
	};

	/**
	 * hg.util.getFilenameFilepath (pathToFile)
	 * - pathToFile : string - path to some file
	 * 
	 * Return: array
	 *
	 * Function cleans the path and returns the path to file and filename in array.
	 * Example 1: /home/user/file -> ['/home/user/', 'file']
	 * Example 2: / -> ['/', '']
	 */
	hg.util.getFilenameFilepath = function (pathToFile) {
		var filename, filePath;
		if (pathToFile == "/") {
			return ["/", ""];
		}

		if (pathToFile.charAt(0) != "/") {
			pathToFile = hg.util.absPath(pathToFile);
		}
		pathToFile = hg.util.cleanPath(pathToFile);
		
		pathToFile = pathToFile.split("/");
		
		filename = pathToFile[pathToFile.length - 1];
		pathToFile = pathToFile.slice(0, pathToFile.length - 1);
		filePath = pathToFile.join("/");
		return [filePath, filename];
	};

	/**
	 * hg.util.getFile (pathToFile)
	 * - pathToFile : string - path to file
	 *
	 * Return: array|null
	 *
	 * Gets the specified file in a informative way. The output array is:
	 * [dirPath, fileName, fileContent, fileType]
	 * - dirPath: path to containing directory
	 * - fileName: filename of file in DirPath
	 * - fileContent: contents of file
	 * - fileType: file type of file
	 * If file doesn't exits or path is incorrect, null is returned.
	 */
	hg.util.getFile = function (pathToFile) {
		var filename, dir, status, filePath, content;
		if (!pathToFile) { return null; }
		
		filePath = hg.util.getFilenameFilepath(pathToFile);
		filename = filePath[1];
		filePath = filePath[0];
		if (filePath == "/" && filename == "")
		{
			return [filePath, filename, 
					hg.state.computer.fs, hg.util.fileType(hg.state.computer.fs)];
		}
		
		if (! filePath) { filePath = "/"; }
		
		status = hg.util.pathIterator(filePath, function (lastDir) {
			dir = lastDir;
		});

		if (status && dir) {
			if (!filename) {
				return [filePath, "", dir, hg.util.fileType(dir)];
			}
			if (dir[filename] !== undefined) {
				content = dir[filename];
				
				return [filePath + (filePath.charAt(filePath.length - 1) == "/" ? "" : "/"), filename, content, hg.util.fileType(content)];
			}
		}

		return null;
	};

	/**
	 * hg.util.setFile (pathToFile, content)
	 * - pathToFile : string - pat to file to set (can be a new file)
	 * - content : mixed - content of the new file
	 * 
	 * Return: boolean
	 * 
	 * Sets new file content if path to file exists and return true. If not, false is returned.
	 */
	hg.util.setFile = function (pathToFile, content) {
		var filename, dir, status, filePath;
		if (pathToFile.charAt(0) != "/") {
			pathToFile = hg.util.absPath(pathToFile);
		}
		pathToFile = hg.util.cleanPath(pathToFile);
		
		if (!hg.util.checkFilePermission(pathToFile)) {
			return null; // not allowed
		}
		pathToFile = pathToFile.split("/");
		
		filename = pathToFile[pathToFile.length - 1];
		pathToFile = pathToFile.slice(0, pathToFile.length - 1);
		filePath = pathToFile.join("/");

		if (!filePath) { filePath = "/"; }
		
		status = hg.util.pathIterator(filePath, function (lastDir) {
			dir = lastDir;
		});
		if (status && dir) {
			dir[filename] = content;
			hg.state.computer.hasChanged = true;
			if (! hg.util.fileExists(hg.state.computer.pwd)) {
				// If something happens to PWD, go to root
				hg.state.changeDir("/");
			}
			return true;
		}
		return false;
	};

	// ===================
	// jQuery util plugins
	// ===================
	/**
	 * jQuery: .hgBlink ([numOfBlinks, [time]])
	 * - numOfBlinks : integer - number of blinks
	 * - time : integer - time between blinks
	 * 
	 * jQuery plugin for DOM element blinking.
	 *
	 */
	$.fn.hgBlink = function (numOfBlinks, time) {
		if (!numOfBlinks) { numOfBlinks = 3; }
		if (!time) { time = 500; }
		$(this).each(function (i, elt) {
			var blink = function (n) {
				if (n > 0) { 
					$(elt).hide(0, function() {
						$(elt).fadeIn(time, function () { 
							blink.call(elt, n-1);
						});
					});
				}
			};
			blink(numOfBlinks);
		});
		return this;
	};
})(jQuery, HackerGame);
/*

HackerGame

*/
(function ($, hg) {
	var addresses = { // address table which returns computers name on a address
			"127.0.0.1": function () { return hg.state.computer.name; }
		}, 
		dnsTable = {  // this is the hostname table
			localhost: "127.0.0.1" 
		}, 
		defaultHome = {
			"download": {},
			"documents": {}
		},
		defaultFs = { // this is the default filesystem passed to every computer
			"bin": { hg: null },
			"home": {},
			"dev": {},
			"tmp": {},
			"etc": {
				"brute": {},
				"dict": { "passwords": "password\npassword1234\n123456789" }
			}
		},
		defaultDynFs = { // this is the default DFS passed to every computer
			
		},
		computers = { // This is the computers array
			// Define computers here in format location: { ... properties ... }
			"-": {
				hostname: "my-machine",
				localIP: "192.168.1.2",
				user: "me",
				externalIP: null,
				visibleFrom: null,
				domain: null,
				commandBlackList: {},
				fs: {},
				dfs: {} // binary files can have 
			}
		};
	// initialize computers, IP map and DNS table
	$.each(computers, function (name, props) {
		var randomIP;
		if (! props.visibleFrom) {
			do {
				randomIP = hg.util.randIP();
			} while (addresses[randomIP]);
			addresses[randomIP] = name;
			computers[name].externalIP = randomIP;
			if (props.domain) {
				dnsTable[prop.domain] = randomIP;
			}
		}
		else {
			addresses[visibleFrom + ">" + props.localIP] = name;
		}

		// Add special
		computers[name].fs = hg.util.extend($.extend(true, {}, defaultFs), 
											computers[name].fs);
		if (!computers[name].fs.home[props.user]) { 
			computers[name].fs.home[props.user] = $.extend(true, {}, defaultHome);
		}

		$.each(defaultDynFs, function (path, fn) { computers[name].dfs[path] = fn; });
		computers[name].fs.etc.hostname = props.hostname;
	});

	/**
	 * hg.cons.Computer (name, isDefault)
	 * - name : string - computer name
	 * - isDefault : boolean - is default computer?
	 * 
	 * Constructor for Computer object.
	 * Fields:
	 * - name : string - computer name
	 * - isDefault : boolean - is default computer
	 * - location : string - local ip address
	 * - pwd : string - current working directory
	 * - hasChanged : boolean - has filesystem changed (important for dumping)
	 * - fs : object - computer file system
	 * - dfs : object - computer dynamic file system
	 * - properties : object - all computer properties in a object
	 *   - hostname : string - computer hostname
	 *   - localIP : string - computer local IP adress 192.168.1.2
	 *   - user: : string - default computer user
	 *   - externalIP (NOT USED)
	 *   - visibleFrom (NOT USED)
	 *   - domain (NOT USED)
	 *   - commandBlackList : object - blacklisted commands
	 */
	hg.cons.Computer = function Computer (name, isDefault) {
		var props = {};
		if (! name) { name = "-"; }
		if (! computers[name]) { return null; }
		this.name = name;
		this.isDefault = isDefault;
		this.location = typeof addresses[name] == "function" ? 
			addresses[name]() : addresses[name];
		this.pwd = "/";
		this.hasChanged = false;
		this.fs = computers[name].fs;
		this.dfs = computers[name].dfs;
		$.each(computers[name], function (property, value) {
			if ($.inArray(property, ["fs", "dfs"]) == -1) { 
				props[property] = value; 
			}
		});
		this.properties = props;

		hg.initComputerCommands(this);
	};

	/**
	 * hg.network.ping (location)
	 * - location : string - location to ping
	 *
	 * Pings 'location' and returns TRUE on success.
	 */
	hg.network.ping = function (location) {
		var isInWeb = addresses[location] || addresses[dnsTable[location]],
			localLocation = hg.state.computer.location + ">" + location,
			isLocal = addresses[localLocation];
		return isInWeb || isLocal;
	};
	
	/**
	 * hg.load.state (obj)
	 * - obj : object - state object
	 *
	 * Load saved state.
	 *
	 * State object can contain two objects:
	 * - state : object - same format as in config
	 * - computer : object
	 *   - user : string
	 *   - hostname : string
	 *   - fs : object - file system (DFS cannot be loaded)
	 */
	hg.load.state = function (obj) {
		if (obj.state) {
			$.each(obj.state.completedAssignments || {}, function (id, stat) {
				var $ass = $(".assignment-list .ass-" + id);

				if (! $ass.length) { return; }

				$ass.find(".ass-current-score").text("-");
				$ass.find(".ass-trials").text(stat.trials || "-");
				$ass.find(".ass-best-score").text(stat.best || "-");
				$ass.find(".ass-name a").addClass("completed-assignment");
				
			});
			
			$('#stats-overall-score').text(obj.state.overallScore || "0");
		}
		if (obj.computer) {
			var cmp = hg.state.getDefaultComputer();
			cmp.properties.user = obj.computer.user;
			cmp.fs = obj.computer.fs;
			cmp.hostname = obj.computer.hostname;
			hg.state.changeDir("/"); 
		}
	};
	
	/**
	 * hg.dump.computer ()
	 *
	 * Dump computer information if changes. Also, mark computer.hasChanges = false
	 * If chanes in filesystem (computer.hasChanges):
	 *   - dump = [ computerObj, callback ]
	 * Else:
	 *   - dump = [ null, callback ]
	 * Computer object has next keys:
	 *   - user : string
	 *   - hostname : string
	 *   - fs : object - file system (DFS cannot be loaded)
	 *
	 * If callback is called, the computer.hasChanges is reset to True
	 */
	hg.dump.computer = function () {
		var fs = null, cmp = hg.state.getDefaultComputer(), status = false;
		if (cmp) { 
			status = cmp.hasChanged; 
			cmp.hasChanged = false; 
		}
		return [(cmp && status) ? {
			fs: cmp.fs,
			hostname: cmp.hostname,
			id: cmp.name,
			user: cmp.properties.user
		} : null, function () {
			cmp.hasChanged = true;
		}];
	};

})(jQuery, HackerGame); 
/*

HackerGame

*/
(function ($, hg) {
	var toText = function (input) {
			var output = "";
			if (typeof(input) === "object") {
				$.each(input, function (_, x) {
					output += hg.t(x) + "\n";
				});
			}
			else { output = input; }
			return output;
		},
		commands = {
			// NETWORK
			"ping": {
				exec: function (loc, num, ttl) {
					var term = this, step, dataString, status, time, 
						responseTime, responseTimeLong, responseTimeShort,
						i = 0,
						timeInSeconds = 1,
						isAvailable = hg.network.ping(loc),
						numOfSuccess = 0,
						timeSuma = 0; 
					if (! num) { num = 5; }
					if (! ttl) { ttl = 60; }
					responseTimeLong = hg.util.randResponseTime(3, ttl*1000);
					responseTimeShort = hg.util.randResponseTime(3, ttl*10);
					responseTime = function () { 
						return Math.random() > 0.2 ? 
							responseTimeShort() : responseTimeLong();
					};
					time = responseTime();
					term.pause();
					step = function () {
						timeSuma += time;
						var proc, stats, continueStep;
						status = isAvailable && Math.random() > 0.05;
						if (status) { numOfSuccess += 1; }
						
						continueStep = function () {
							dataString = "icmp_seq=" + (i + 1) 
								+ " ttl="+ttl+" time=" 
								+ (status ? (time/1000) : ttl) + " ms";
							hg.terminal.echo(hg.t("Pinging") + " " + loc + " ... " + dataString + " " + hg.t(status ? "OK" : "LOST"));
							i += 1;
							if (i < num) {
								time = responseTime();
								setTimeout(step, timeInSeconds*1000 + time/1000); 
							}
							else {
								proc = ((num-numOfSuccess)/num*100);
								proc = Math.round(proc * 1000)/1000;
								stats = num + " " + hg.t("packets transmited") + ", " + numOfSuccess 
									+ " " + hg.t("recieved") + ", " 
									+ proc + "% pacet loss, time " + timeSuma;
								hg.terminal.echo("\n--- " + loc + " ping statistics ---");
								hg.terminal.echo(stats);
								term.resume();
							}
						};
						if (!status) {
							time += ttl*1000 - time/1000;
							setTimeout(continueStep, ttl*1000 - time/1000);
						}
						else {
							continueStep();
						}
					};
					setTimeout(step, time/1000);
				},
				help: ["ping - send a ping package to remote computer", 
					   "Usage: ping IP|DOMAIN [NUMBER_OF_PINGS=5 [TIME_TO_LIVE=60]]",
					   "Example: ping localhost",
					   "TIME_TO_LIVE is in seconds.",
					   "Linux: ping"]
			},
			// PASWORD CRACKERS
			"brute": {
				exec: function (pathToFile, num) {
					var fileData = hg.util.getFile(pathToFile), result, special, fails = [],
						charGenerator = function () {
							var chrNum = 97;
							return function () {
								var str = String.fromCharCode(chrNum);
								if (chrNum > 122) { return null; }
								chrNum++;
								return str;
							};
						},
						brute = function (n, str) {
							var i = 0, gen = charGenerator(), chr = gen(), status;
							if (!str) { str = ""; }
							while(chr) {
								if (n > 1) {
									status = brute(n-1, str + chr);
									if (status) { return status; }
								}
								else {
									status = special(str + chr)[0];
									if (status) { 
										fails.push(hg.t("Success") + ": " + str+chr);
										return str + chr;
									}
									fails.push(hg.t("Try") + ": " + str+chr);
								}
								chr = gen();
							}
						};
					if (! num) { num = 0; }
					else { num = parseInt(num, 10); }
					if (fileData !== null) {
						special = hg.util.getSpecialFile(fileData[0] + fileData[1]);
						if (special() !== null) { 
							hg.tEcho("Brute force attack!!!");
							hg.term.pause();
							if (num == 0) {
								num = 1;
								while(!result && num <= 3) {
									result = brute(num);
									
									num++;
								}
							}
							else if (num > 3) {
								hg.term.echo(num + hg.t(" is too much for this computer. Trying 3 characters ..."));
							}
							else {
								result = brute(num);
							}
							if (result) {
								hg.term.echo(hg.t("Password found") + ": " + result);
								hg.term.echo(hg.t("Try") + ": edit " + pathToFile + " " + result);
							}
							else {
								hg.tEcho("Brute force failed.");
							}
							hg.util.setFile("/tmp/brute.log", fails.join("\n"));
							hg.term.echo(hg.t("Log dumped to") + ": /tmp/brute.log");
							hg.term.echo(hg.t("To view use command") + ": edit /tmp/brute.log");
							hg.term.resume();
						}
						else {
							hg.tError("File is not password protected.");
						}
					}
					else {
						hg.tError("File doesn't exist!");
					}
				},
				help: ["brute - use brute force attack to crack password protected file",
					   "Usage: brute FILE [NUM]",
					   "- FILE: password protected file",
					   "- NUM (optional): number of characters",
					   "                  if not specified, NUM=1..3",
					   "Example: brute file.txt 3"]
			},
			"dict": {
				exec: function (pathToFile) {
					var fileData = hg.util.getFile(pathToFile), 
						result, special, dict = "/etc/dict/passwords",
						passwords = [],
						fails = [];
					
					if (fileData !== null) {
						special = hg.util.getSpecialFile(fileData[0] + fileData[1]);
						if (special() !== null) { 
							hg.tEcho("Dictionary attack!!!");
							hg.term.pause();
							
							dict = hg.util.getFile(dict);
							if (dict === null) {
								hg.tError("Error: no dictionary file in" + "/etc/dict/passwords");
								hg.term.resume();
								return;
							}
							passwords = dict[2].split("\n");
							$.each(passwords, function (i, pass) {
								if (pass === "") { return; }
								result = special(pass)[0];
								if (! result) {
									fails.push(hg.t("Try") + ": " + pass);
								}
								else {
									fails.push(hg.t("Success") + ": " + pass);
									result = pass;
								}
								return typeof(result) === typeof(false);
							});

							if (result) {
								hg.term.echo(hg.t("Password found") + ": " + result);
								hg.term.echo(hg.t("Try") + ": edit " + pathToFile + " " + result);
							}
							else {
								hg.tEcho("Dictionary attack failed.");
							}
							hg.util.setFile("/tmp/dict.log", fails.join("\n"));
							hg.term.echo(hg.t("Log dumped to") + ": /tmp/dict.log");
							hg.term.echo(hg.t("To view use command") + ": edit /tmp/dict.log");
							hg.term.resume();
						}
						else {
							hg.tError("File is not password protected.");
						}
					}
					else {
						hg.tError("File doesn't exist!");
					}
				},
				help: ["dict - use common passwords to crack password protected file",
					   "Usage: dict FILE",
					   "Example: dict file.txt"]
			},
			// FILE SYSTEM
			"cat": {
				exec: function (file) {
					var term = this, contents = hg.util.getFile(file);
					if (contents === null) {
						hg.tError("File doesn't exist!");
						return;
					}
					contents = contents[2];
					if (contents === null) {
						hg.tError("Cannot display binary files.");
					}
					else if (typeof(contents) == "object") {
						hg.tError("Cannot display directory contents.");
					}
					else {
						hg.tEcho(contents);
					}

				},
				help: ["cat - display file contents",
					   "Usage: cat FILE",
					   "Example: cat /etc/hostname",
					   "Linux: cat FILE"]
			},
			"tree": {
				exec: function (dir) {
					var correctPath = dir || hg.state.computer.pwd,
						absPath = correctPath.charAt(0) == "/" ? correctPath : hg.util.absPath(correctPath),
						cleanPath = hg.util.cleanPath(absPath),
						path = hg.util.path(cleanPath),
						term = this,
						start = "/",
						place = hg.state.computer.fs,
						node = function (level) {
							var out = '';
							while (level-- > 0) {
								out += "   ";
							} 
							return out + "`--";
						},
						iterator = function (currPlace, level) {
							$.each(currPlace, function (name, file) {
								type = hg.util.fileType(file);
								hg.tEcho(node(level) + name + " [" + type + "]");
								if (type == "d") {
									iterator(file, level+1);
								}
							});
						};
					if (path.length > 0) {
						$.each(path, function (i, sub) {
							start = sub;
							place = place[sub] || {};
						});
						if (! place) {
							hg.tError("Directory doesn't exist!");
							return;
						}
					}
					hg.tEcho(start);
					iterator(place, 0);
					
				},
				help: ["tree - see the file hierarchy in the form of a tree",
					   "If no directory is specified, the working directory hierarchy",
					   "is displayed.",
					   "Usage: tree [DIRECTORY]",
					   "Example 1: tree",
					   "Example 2: tree /",
					   "Linux: tree [DIRECTORY]"]
			},
			"ls": {
				exec: function (folder) {
					var dirs = ". ..", place = hg.util.getFile(folder || ".");
					
					if(! place || typeof(place) != "object") { 
						hg.tError("Directory doesn't exist!");
						return;
					}
					
					$.each(place[2], function (k, _) {
						dirs += " " + k;
					});
					hg.tEcho(dirs);
				},
				help: ["ls - list directory contents",
					   "Usage: ls [DIRECTORY]",
					   "Example 1: ls",
					   "Example 2: ls /home",
					   "Linux: ls [DIRECTORY]"]
			},
			"mkdir": {
				exec: function (folder) {
					var er = hg.state.makeDir(folder);
					if (er) { hg.tError(er); } 
				},
				help: ["mkdir - create a directory",
					   "Usage: mkdir DIRECTORY",
					   "Example: mkdir /tmp/new_directory",
					   "Linux: mkdir dir1, [dir2, [dir3, ...]]"]
			},
			"pwd": {
				exec: function () { 
					hg.tEcho(hg.state.computer.pwd); 
				},
				help: ["pwd - path to current directory",
					   "Usage: pwd",
					   "Example: pwd",
					   "Linux: pwd"]
			},
			"cd": {
				exec: function (fold) {
					if (! fold) { fold = "/home/" + hg.state.computer.properties.user; }
					if (! hg.state.changeDir(fold)) {
						hg.tError(fold + " is not a directory");
					}
				},
				help: ["cd - change directory",
					   "Usage: cd [PATH]",
					   "Example 1: cd ..",
					   "Example 2: cd /home",
					   "Linux: cd path"]
			},
			"mv": {
				exec: function (src, dst) {
					var status = false, args = src && dst;
					if (args) {
						status = hg.state.move(src, dst);
					}
					if (!status) {
						hg.tError("Something wrong with the path.");
					}
				},
				help: ["mv - move file",
					   "Usage: mv FILE NEW_FILE",
					   "Example: mv /tmp/dir /dir",
					   "Linux: cp"]
			},
			"cp": {
				exec: function (src, dst) {
					var status = false, args = src && dst;
					if (args) {
						status = hg.state.copy(src, dst);
					}
					if (!status) {
						hg.tError("Something wrong with the path.");
					}
				},
				help: ["cp - copy file",
					   "Usage: cp FILE NEW_FILE",
					   "Example: cd /tmp /tmp2",
					   "Linux: cp"]
			},
			"rm": {
				exec: function (path) {
					var fullPath = null, 
						file = hg.util.getFile(path),
						term=this;
					if (hg.util.checkFilePermission(path, true)) {
						hg.state.removeFile(path);
					}
					else {
						hg.tError("Cannot remove root!");
					}
				},
				help: ["rm - remove file or directory",
					   "Usage: rm PATH",
					   "Example: rm /tmp/file",
					   "Linux: rm path_to_file OR rmdir path_to_empty_directory"]
			},
			// EDITING
			"edit": {
				help: ["edit - edit file",
					   "Usage: edit FILE [KEY]",
					   "- KEY: optional, if file is password protected",
					   "Example 1: edit /etc/hostname",
					   "Example 2: edit /tmp/protected thisIsAFilePassword",
					   "Linux: there are many command line programs for editing files,", 
					   "but they are not necessarily installed.",
					   "- joe FILE",
					   "- nano FILE",
					   "- emacs FILE",
					   "- vi FILE",
					   "- vim FILE"],
				exec: function (file, key) {
					hg.editor.openCallback = function () {
						hg.editor.focus();
					};
					hg.editor.closeCallback = function () {};
					var response = hg.editor.watch(file, key);
					if (response) {
						hg.tError(response);
					}
					else {
						hg.editor.focus();
					}
				}
			},
			// INTERNAL
			"eval": {
				help: ["eval - execute a JavaScript command", 
					   "Usage: eval COMMAND"]
			},
			"export": {
				help: ["export - store a variable",
					   "Usage: export VARIABLE=VALUE",
					   "Linux: export VARIABLE=VALUE"]
			},
			"sensei": {
				exec: function (input) { 
					hg.tEcho("Message to sensei sent."); 
				},
				fullArgs: true,
				help: ["sensei - send a message to sensei via secure connection",
					   "Usage: sensei MESSAGE",
					   "Example: sensei Hello sensei, how are you?"]
			},
			"echo": {
				exec: function (input) { 
					if (input) { hg.tEcho(input); }
				},
				fullArgs: true,
				help: ["echo - print text in terminal", 
					   "Usage: echo TEXT",
					   "Example: echo Hello!",
					   "Linux: echo TEXT"]
			},
			"help": {
				exec: function(command) {
					var blackList = hg.state.computer.properties.commandBlackList;
					if (!command) {
						hg.tEcho("Available commands: ");
						$.each(commands, function (cmnd, props) {
							if ($.inArray(cmnd, blackList) > -1) {
								return;
							}
							hg.tEcho(props.help[0]);
						});
						hg.tEcho("\nFor more information type: help COMMAND");
					}
					else if (commands[command]){
						hg.term.echo(toText(commands[command].help));
					}
					else {
						hg.tError("No information on command" + " " + command);
					}
				},
				help: ["help - display help information", 
					   "Usage: help [COMMAND]",
					   "Example 1: help",
					   "Example 2: help ls",
					   "Linux: man or COMMAND -h or COMMAND --help"]
			}
		};
	/**
	 * hg.commandCompletion (term, string, fn)
	 * - term : object - terminal object
	 * - string : string - current input string
	 * - fn : function - terminal callback
	 *
	 * Searches trough available commands and returns the candidates for command
	 * completion.
	 */
	hg.commandCompletion = function (term, string, fn) {
		var candidates = [];
		// Commands
		$.each(commands, function (cmnd, _) {
			if (cmnd.substr(0, string.length) == string) {
				candidates.push(cmnd);
			}
		});

		// Folders and files
		$.each(hg.state.place, function (file, _) {
			if (file.substr(0, string.length) == string) {
				candidates.push(file);
			}
		});
		
		fn(candidates);
	};

	/**
	 * hg.initComputerCommands (computer)
	 * Initializes basic computer comands when the computer is initialized.
	 */
	hg.initComputerCommands = function (computer) {
		$.each(commands, function (name, _) {
			computer.fs.bin[name] = null;
		});
	};
	
	/**
	 * hg.exec (input, term)
	 * - input : string - user input
	 * - term : object - terminal object
	 * 
	 * Evaluates user input. This is the most important function called from the terminal.
	 * It serches for available commands or parses the input to javascript or displays
	 * an error. It also calls the assignment callback for evaluating tasks.
	 *
	 * THIS FUNCTION IS PASSED TO THE TERMINAL.
	 */
	hg.exec = function(input, term) {
		var segments = hg.util.parseInput(input),
			fn = segments[0],
			argsString = segments[1],
			args = segments[2],
			argsStringRaw = segments[3],
			result, evalObj,
			noError = true,
			callbackResult;
		if (args === null) {
			term.error(hg.t("Parse error") + ": " + argsStringRaw);
		}
		else if ($.inArray(fn, hg.state.computer.properties.commandBlackList) > -1) {
			noError = false;
			hg.tError("Command is not defined!");
		}
		else if (commands[fn] && commands[fn].exec) {
			if (commands[fn].fullArgs) { result = commands[fn].exec.call(term, argsString); }
			else { result = commands[fn].exec.apply(term, args); }
		}
		else if(fn === "eval" || fn === "export") {
			if (argsStringRaw) {
				try {
					result = window.eval(argsStringRaw);	
					hg.tEcho(new String(result));
				} catch(e) {
					hg.tError(new String(e));
            	}
			}
		}
		else if (input != '') {
			noError = false;
			hg.tError("Command is not defined!");
		}
		if (input != '' && hg.assignment && hg.assignment.currentTask >= 0 && hg.assignment.evaluate) {
			evalObj = {
				input: input,
				command: fn,
				argsString: argsString,
				args: args,
				noError: noError
			};
			
			// Callback is the main task checker.
			// If the input passes the callback
			// You can move to the next task
			callbackResult = hg.assignment.evaluate.call(term, evalObj);

			if ($.isFunction(hg.assignment.bonus)) {
				if(hg.assignment.bonus.call(term, evalObj)) {
					hg.assignment.queue.push("bonus");
				}
			}

			if (callbackResult) {
				hg.assignment.nextTask();
			}
		}
		
	};
})(jQuery, HackerGame);

/*

HackerGame

*/
(function ($, hg) {
	var stateCache = [], 
		/**
		 * state: timeToScore ()
		 *
		 * Return: integer
		 *
		 * Convert remaining time to score.
		 */
		timeToScore = function () {
			return parseInt(hg.timer.lastCounter / 20, 10);
		},
	
		/**
		 * state: evalAssignmentQueue ()
		 *
		 * Evaluate assignment queue. Calculate bonuses etc.
		 */
		evalAssignmentQueue = function () {
			var task = this,
				actions = {
				hint: function () {
					hg.stats.increment("currentScore", - parseInt(0.75 * task.points, 10));
				},
				bonus: function () {
					hg.stats.increment("currentScore", parseInt(0.25 * task.points, 10));
				}
			};
			if (hg.assignment.queue.length > 0) {
				$.each(hg.assignment.queue, function (i, elt) {
					if (actions[elt]) { actions[elt](); }
				});
				hg.assignment.queue = [];
			}
		},
	
		/**
		 * state: closeTask
		 *
		 * Close current task.
		 */
		closeTask = function (id) {
			$("#tab-task .tasks-list #task-"+id).addClass("completed-task");
			$("#tab-task .tasks-list #task-"+id).find(".hint, .help").popover('destroy').empty().remove();
		},

		/**
		 * state: loadAssignment (assId, [callback])
		 * - assId : string - assignment id
		 * - callback : function - callback called when script file is loaded
		 *
		 * Load assignment HTML and JavaScript. First HTML is loaded into #stash div element.
		 * Then the JS is loaded and evaluated (it can use its HTML elements 
		 * directly from #stash. Callback is called if script is successfully loaded.
		 */
		loadAssignment = function (assId, callback) {
			var htmlUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".html",
				htmlLangUrl = hg.config.basePath + hg.config.assignmentsPath + assId + "-" + hg.lang + ".html",
				jsUrl = hg.config.basePath + hg.config.assignmentsPath + assId + ".js",
				loadJS = function (html) {
					$("#stash").html(html);
					$.getScript(jsUrl, callback);
				};
			$.ajax({
				url: htmlLangUrl,
				method: 'get',
				dataType: 'html',
				success: loadJS,
				error: function() {
					// If no language markup file exists, load the default (English) file
					$.ajax({
						url: htmlUrl,
						method: 'get',
						dataType: 'html',
						success: loadJS
					});
				}
			});
		};
	/**
	 * hg.cons.State (computer, [config, [innerState]])
	 * - computer : object - computer object
	 * - config : object - configuration for the state
	 * - innerState : object - NOT USED YET
	 * 
	 * Constructor for State object.
	 * 
	 * Object fields:
	 * - computer : object - computer object
	 * - place : object - directory object for current working directory
	 * 
	 * Object methods:
	 * - hasCompletedAssignments ()
	 * - getDefaultComputer () 
	 * - changeDir (directory)
	 * - makeDir (directory)
	 * - removeFile (filePath)
	 * - openFile (filePath)
	 * - saveFile (filePath, content)
	 * - emptyTmp ()
	 * - copy (src, dst)
	 * - move (src, dst)
	 */
	hg.cons.State = function State(computer, config, innerState) {
		this.computer = computer || new hg.cons.Computer(hg.config.defaultComputer, true);
		
		this.innerState = innerState;
		if (config && typeof config === "object") { //TODO: use extend
			$.each(config, function (property, value) {
				this[property] = value;
			});
		}

		this.place = this.computer.fs;
	};
	hg.cons.State.prototype.hasCompletedAssignment = function (assId) {
		var bestScore, $elt = $("table.assignment-list .ass-"+assId);
		if ($elt.length > 0) {
			bestScore = $elt.find(".ass-best-score").text();
			if (bestScore && bestScore != "-") {
				return parseInt(bestScore, 10);
			}
		}
		return 0;		
	};
	hg.cons.State.prototype.getDefaultComputer = function () {
		return this.computer.isDefault ? 
			this.computer : (this.innerState ? 
							 this.innerState.getDefaultComputer() : null);
	};
	hg.cons.State.prototype.changeDir = function (fold) {
		var res;
		if (fold.charAt(0) != "/") {
			fold = hg.util.absPath(fold);
		}
		if (hg.util.isDir(fold)) {
			hg.util.pathIterator(fold, function (place) {
				hg.state.place = place;
			});
			hg.state.computer.pwd = hg.util.cleanPath(fold);
			if (hg.state.computer.pwd.length == 0) {
				hg.state.computer.pwd = "/";
			}
			res = true;
		}
		else { res = false; }
		return res;
	};
	hg.cons.State.prototype.makeDir = function (fold) {
		var err = false;
		if (typeof(fold) != "string") { err = "Path not valid!"; }
		else {
			var exists = hg.util.getFile(fold);
			if (hg.util.fileExists(fold)) {
				err = "File already exists!";
			}
			if (!err) {
				err = hg.util.setFile(fold, {});
				if (! err) { err = "Path doesn't exist!"; }
				else { err = false; }
			}
		}
		return err;
	};
	hg.cons.State.prototype.removeFile = function (filePath) {
		var path, er = false, place = this.computer.fs;
		if (typeof(filePath) != "string") { er = "Path not valid!"; }
		else {
			path = filePath;
			if (path.charAt(0) != "/") { path = hg.util.absPath(path); }

			path = hg.util.cleanPath(path);

			path = path.split("/").slice(1);
			$.each(path, function (i, elt) {
				if (i >= path.length - 1) {
					if (place[elt] !== undefined) {
						delete place[elt];
						hg.state.computer.hasChanged = true;
						if (! hg.util.fileExists(hg.state.computer.pwd)) {
							hg.state.changeDir("/");
						}
						// TODO: check if PWD exists!!!
					}
					else {
						er = "Directory already exists!";
					}
				}
				else if (place[elt] === undefined) {
					er = "Path doesn't exist!";
				}
				else if (place[elt] !== null && typeof(place[elt]) == "object") {
					place = place[elt];
				}
				else {
					er = "Path doesn't exist!";
					return -1;
				}
			});
		}
		return er;

	};
	hg.cons.State.prototype.openFile = function (path) {
		var file = hg.util.getFile(path);
		if (file) {
			return file[3];
		}
		return false;
	};
	hg.cons.State.prototype.saveFile = function (path, content) {
		return hg.util.setFile(path, content);
	};
	
	hg.cons.State.prototype.emptyTmp = function () {
		hg.util.setFile("/tmp", {});
	};

	hg.cons.State.prototype.copy = function (src, dst, move) {
		var from = hg.util.getFile(src), to;
		if (! from) { return false; }
		if (move && !hg.util.checkFilePermission(src, true)) {
			return null;
		}
		if (hg.util.isDir(dst)) {
			to = hg.util.getFile(dst);
			if (to) {
				if (move || from[2] === null || typeof(from[2]) != "object") {
					to[2][from[1]] = from[2];
				}
				else {
					// Deep copy
					to[2][from[1]] = jQuery.extend(true, {}, from[2]);
				}
			}
			else {
				return false;
			}
		}
		else {
			if (move || from[2] === null || typeof(from[2]) != "object") {
				hg.util.setFile(dst, from[2]);
			}
			else {
				// Deep copy
				hg.util.setFile(dst,jQuery.extend(true, {}, from[2])); 
			}
		}
		if (move) {
			hg.state.removeFile(src);
		}

		hg.state.computer.hasChanged = true;
		if (! hg.util.fileExists(hg.state.computer.pwd)) {
			// If something happens to PWD, go to root
			hg.state.changeDir("/");
		}
		return true;
	};

	hg.cons.State.prototype.move = function (src, dst) {
		return hg.state.copy(src, dst, true);
	};

	/**
	 * hg.cons.Task (taskObj, taskHtml)
	 * - taskObj : object - task configurations
	 * - taskHtml : string - task html from #stash
	 *
	 * Object taskObj:
	 * - evaluate : function - callback when user uses a command
	 * - set : function - callback when task is initialized
	 * - unset : function - callback when task is destroyed
	 * - points : number - points user can achieve with this task
	 * - bonus : function - add a callback to check if bonus should be added
	 *
	 * Constructor for Task object.
	 *
	 * Object fields:
	 * - id : string
	 * - evaluate : function
	 * - set : function
	 * - unset : function
	 * - pointes : function
	 * 
	 * Object methods:
	 * - switchTask (previousTask) - switch between tasks
	 */
	hg.cons.Task = function Task(taskObj) {
		this.id = taskObj.id || null;
		this.evaluate = taskObj.evaluate || function () { return true; };
		this.set = taskObj.set || function () {};
		this.unset = taskObj.unset || function () {};
		this.points = taskObj.points;

		hg.assignment.maxTaskPoints += this.points;

	};
	hg.cons.Task.prototype.switchTask = function (previousTask) {
		var scrollPos = 0;
		if (previousTask) { 
			$("#task-" + previousTask.id).addClass("past-task");
			previousTask.unset(); 
		}
		
		this.set();

		$("#task-" + this.id).removeClass("future-task");


		hg.assignment.evaluate = this.evaluate;
	};

	/**
	 * hg.cons.Assignment (assId, loadCallback)
	 * - assId : assignment id
	 *
	 * Constructor for Assignment object.
	 * Note: this gets called before assignment is initialized.
	 * Constructor also calls loadAssignment ()
	 *
	 * Object fields:
	 * - id : string - assignment id
	 * - currentTask : integer - pointer to current task
	 * - numOfTasks : integer - number of tasks
	 * - tasks : array - container for Task objects
	 * - isRunning : boolean - true when assignment is initialized and started (running)
	 * - startTime : integer - starting counter for timer
	 * - evaluate : function - evaluate function for every assignment
	 * - queue : array - assignment actions queue
	 * - maxTaskPoints : integer - maximum number of points tasks can bring
	 * - bestScore : integer - best assignment score
	 *
	 * Object methods:
	 * - startTimer () - start hg.timer
	 * - nextTask () - switch to next task
	 * - fail () - called when assignment fails
	 * - complete () - called when all tasks are completed
	 */
	hg.cons.Assignment = function Assignment(assignment, loadCallback) {
		
		this.id = assignment;
		this.currentTask = -1;
		this.numOfTasks = 0; // set with array length
		this.tasks = []; // array of task objects 
		this.isRunning = false;
		this.startTime = 0;
		this.evaluate = function () { return true; };
		this.queue = [];

		this.maxTaskPoints = 0;
		this.bestScore = hg.state.hasCompletedAssignment(assignment);
		
		hg.stats.currentScore = 0;
		hg.stats.completedTasks = 0;


		loadAssignment(assignment, loadCallback);
	};
	hg.cons.Assignment.prototype.startTimer = function () {
		if (this.startTime) { hg.timer.start(); }
	};
	hg.cons.Assignment.prototype.nextTask = function () {
		var nextTask,
			prevTask = this.currentTask >= 0 ? this.tasks[this.currentTask] : undefined;
		nextTask = this.tasks[this.currentTask + 1];
		this.currentTask += 1;

		if (nextTask) { 
			nextTask.switchTask(prevTask);
		}

		if (prevTask) { 
			closeTask(prevTask.id);
			hg.stats.increment({
				currentScore: prevTask.points,
				completedTasks: 1
			});
			evalAssignmentQueue.call(prevTask); 
		}
		
		if (! nextTask) { hg.assignment.complete(); }
	};
	hg.cons.Assignment.prototype.fail = function () {
		var $trials = $(".assignment-list .ass-" + this.id + " .ass-trials"),
			trialsNum = parseInt($trials.text(), 10) || 0;
		hg.timer.stop();
		
		hg.stats.currentScore = 0;
		hg.stats.refresh();

		stateCache.push({
			"type": "assignment",
			"key": this.id,
			"value": -1
		});
		hg.assignment.failCallback();

		$trials.text(trialsNum + 1);
		hg.action.page("assignments");
		

		hg.msg.alert("Sorry, you failed. Your time is up. But try again! Failing is an important part of learing. ", "Time's up! You got cought!");

		hg.assignment = null;
	};
	hg.cons.Assignment.prototype.complete = function () {
		var $tr = $(".assignment-list .ass-"+hg.assignment.id),
			bestScore = $tr.find(".ass-best-score").text(),
			trials = $tr.find(".ass-trials").text(),
			msg = "";
		hg.timer.stop();

		if (this.bestScore == 0) {
			hg.stats.increment({
				completedAssignments: 1
			});
		}

		$tr.find(".ass-name a").addClass("completed-assignment");

		hg.stats.increment({
			currentScore: timeToScore()
		});

		if (bestScore == "-" || (parseInt(bestScore, 10) < hg.stats.currentScore)) {
			bestScore = hg.stats.currentScore;
		}
		trials = parseInt(trials, 10) || 0;

		$tr.find("td.ass-best-score").text(bestScore);
		$tr.find("td.ass-current-score").text(hg.stats.currentScore);
		$tr.find("td.ass-trials").text(trials);

		hg.stats.aggregate();


		stateCache.push({
			"type": "assignment",
			"key": this.id,
			"value": hg.stats.currentScore
		});

		msg = hg.t("You have successfully completed the assignment.") + ".<br />"
			+ hg.t("Your current score is") + ": " + hg.stats.currentScore + ".<br />"
			+ hg.t("Your best score is") + ": " + bestScore + ".<br />";
		
		hg.msg.alert(msg, "Assignment completed!");



		hg.assignment.successCallback();
		hg.action.page("assignments");
		hg.assignment = null;
	};

	hg.stats = {
		/**
		 * hg.stats.refresh ([exlude])
		 * - exclude : array - stats to exclude from refreshing (NOT YET USED)
		 * 
		 * Function refreshes the stats values in DOM.
		 */
		refresh: function (exclude) {
			var overallAssignments = hg.ind.NUM_OF_ASSIGNMENTS,
				tasksInAssignment = hg.assignment ? hg.assignment.tasks.length : 0;
			if (!exclude) { exclude = []; }
			// TODO: can we do something with exclude or is it just in the way?
			$("#stats-completed-tasks").text(hg.stats.completedTasks + "/" + tasksInAssignment);
			$("#stats-completed-assignments").text(hg.stats.completedAssignments + "/" + overallAssignments);
			$("#stats-current-score").text(hg.stats.currentScore);
			$("#stats-best-score").text(hg.stats.bestScore);
			$("#stats-overall-score").text(hg.stats.overallScore);
		},
		/**
		 * hg.stats.aggregate ([hold])
		 * - hold : boolean - if true, don't automatically refresh stats
		 *
		 * Aggregates overall score.
		 */
		aggregate: function (hold) {
			$(".table.assignment-list tr").each(function (i, elt) {
				var best = $(elt).find(".ass-best-score").text();
				if (best && best != "-") { best = parseInt(best, 10); }
				else { best = 0; }
				hg.stats.overallScore += best;
			} );
			if (! hold) { hg.stats.refresh(); }
		},
		
		/**
		 * hg.stats.increment (stat, val, [hold])
		 * - stat : string - stat to be incremented
		 * - val : integer - increment stat by value
		 * - hold : boolean - if true, don't refresh stats after changes
		 *
		 * Increment stats.
		 */
		increment: function (stat, val, hold) {
			if (typeof(stat) == "object") {
				$.each(stat, function (key, inc) {
					if (hg.stats[key] !== undefined && !$.isFunction(hg.stats[key])) {
						hg.stats[key] += (parseInt(inc, 10) || parseFloat(inc, 10)) ? inc : 0;
					}
				});
			}
			else if (hg.stats[stat] !== undefined && !$.isFunction(hg.stats[stat])) { 
				hg.stats[stat] += val; 
			}
			if (! hold) { hg.stats.refresh(); }
		},
		completedAssignments: 0,
		completedTasks: 0,
		bestScore: 0,
		currentScore: 0,
		overallScore: 0
	};

	// Actions (which user can do)
	/**
	 * hg.action
	 *
	 * Special module with functions that get triggered by location hashes.
	 * Spec: #/actionMethod/actionArgument -> hg.action.actionMethod (actionArgument)
	 * Example: #/page/help -> hg.action.page (help)
	 */

	/**
	 * hg.action.page (pageId)
	 * - pageId : string - page id to switch to
	 * 
	 * Switch page
	 */
	hg.action.page = function (pageId) {
		var prevPageIdRaw = $("#page-links .active").attr("id"),
			prevPageId = prevPageIdRaw && prevPageIdRaw.substr(10),
			pageDisabled = $("#link-page-" + pageId+".disabled").length > 0,
			showPage = function () {
				$("#link-page-" + pageId).addClass("active"); 
				$("#page-" + pageId).show("slow");
			};
		
		if (pageDisabled) { return; }
		if (prevPageId) { 
			$("#link-page-" + prevPageId).removeClass("active"); 
			$("#page-" + prevPageId).hide("slow", showPage);
		}
		else {
			showPage();
		}
	};

	/**
	 * hg.action.input (inputId)
	 * - inputId : string - input tab to change to
	 *
	 * Change input tab.
	 */
	hg.action.input = function (inputId) {
		var prevInputId = $("#input-links .active").attr("id").substring(11),
			showInput = function () {
				$("#link-input-" + inputId).addClass("active"); 
				$("#input-" + inputId).show(0);
			};
		if (prevInputId) {
			$("#link-input-" + prevInputId).removeClass("active"); 
			$("#input-" + prevInputId).hide(0, showInput);
		}
		else {
			showInput();
		}
	};

	/**
	 * hg.action.tab (tabId)
	 * - tabId : string - info tab to change to
	 * 
	 * Change info tab.
	 */
	hg.action.tab = function (tabId) {
		var prevTabId = $("#tab-links .active").attr("id").substring(9),
			showTab = function () {
				$("#link-tab-" + tabId).addClass("active"); 
				$("#tab-" + tabId).show(0);
			};
		if (prevTabId) {
			$("#link-tab-" + prevTabId).removeClass("active"); 
			$("#tab-" + prevTabId).hide(0, showTab);
		}
		else {
			showTab();
		}
	};

	/**
	 * hg.action.assignment (assId)
	 * - assId : string - selected assignment
	 * 
	 * Select assignment.
	 */
	hg.action.assignment = function (assId) {
		var status = false;

		if (hg.assignment) { return; }

		// TODO: this can be done better now
		$.each(hg.config.assignments, function (i, obj) {
			if (obj.id == assId) { status = true; }
		});

		if (! status) { return; }

		hg.assignment = new hg.cons.Assignment(assId, function () {
			hg.refreshTranslations(hg.config.assignmentScopeSelector);
		});

		$("#link-tab-game").removeClass("disabled");
	};

	/**
	 * hg.action.mail ()
	 * 
	 * Open email.
	 */
	hg.action.mail = function (cmnd) {
		if (cmnd == "open") { hg.mail.open(); }
	};

	/**
	 * hg.dump.state ()
	 * 
	 * Return: array
	 *
	 * Dump state to JSON. 
	 * Return format: [stateJson, callback]
	 * Object stateJson can be null if no state changes exist.
	 * Callback resets the changes back to previous state. Everything
	 * That has happend between one dump and one callback call is also
	 * appended to the state. 
	 */
	hg.dump.state = function () {
		var tmpCache = stateCache;
		stateCache = []; // clear cache
		return [tmpCache.length > 0 ? tmpCache : null, function () {
			// Note: If connection error
			// The current assignments cache needs to be
			// reverted back. Also, changes that were made
			// before the packing need to be saved.
			tmpCache.push.apply(tmpCache, stateCache);
			stateCache = tmpCache;
		}];
	};
})(jQuery, HackerGame);
(function ($, hg) {

	/* hg.config
	 *  
	 * Configuration object. Everything can be overwritten trough settings.
	 */
	hg.config = {
		// Where to refresh translations when a new assignment is loaded
		assignmentScopeSelector: ".assignment-scope",
		// What is users default computer
		defaultComputer: "-",
		// Terminal settings
		terminal: {
			greetings: 'Welcome!',
			name: 'hacker-terminal',
			height: 400,
			tabcompletion: true
		},
		// Base path for AJAX loads
		basePath: "", // TODO: use this!!!
		// Assignments path
		assignmentsPath: "ass/", // TODO: use this!!
		// Path to images
		imagesPath: "img/", // TODO: use this!!!
		// Assignments array of objects in form { id: ID, name: NAME } or seperator strings
		assignments: [
			"Training",
			{ 
				id: "intro",
				name: "Introduction to the terminal"
			},
			{
				id: "fs",
				name: "Tidying up"
			},
			{
				id: "password1",
				name: "Let's crack some passwords"
			},
			"Level 1",
			{
				id: "password2",
				name: "Get the secret word"
			}
		],
		// Default user information: this refreshes the dynamic fields
		user: {
			email: "",
			name: "Anon"
		},
		// Default state information
		state: {
			completedAssignments: {},
			overallScore: 10
		}
	};
})(jQuery, HackerGame);

