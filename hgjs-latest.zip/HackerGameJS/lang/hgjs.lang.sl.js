HackerGame.load.language("sl", {
	// Interface
	"Toggle navigation": "Skrij/prikaži navigacijo",
	"HackerGameJS": "HackerGameJS",
	"Getting started": "Kako začeti?",
	"Game": "Igra",
	"Help": "Pomoč",
	"Terminal": "Terminal",
	"Editor": "Urejevalnik",
	"Assignment": "Misija",
	"Tasks": "Naloge",
	"Try it out!": "Poskusi sam",
	"Tasks completed": "Opravljene naloge",
	"Time left": "Preostali čas",
	"Assignments completed": "Opravljene misije",
	"Disclaimer": "Omejitev odgovornosti",
	"Learn more": "Osvoji še več",
	
	// Assignments
	"Introduction to the terminal": "Uvod v konzolo"
});
